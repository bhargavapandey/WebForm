# Document Processing Guide

## Overview
The Pharmacovigilance Case Intake Service can now process unstructured documents and extract case data automatically.

## How to Test

### 1. **Process a Single File**
```powershell
cd c:\Work\dotnet\PharmacovigilanceIntakeService
dotnet run <file_path> [output_folder]
```

**Example:**
```powershell
dotnet run C:\documents\patient_report.txt
```

### 2. **Process a Folder**
```powershell
dotnet run <folder_path> [output_folder]
```

**Example:**
```powershell
dotnet run C:\email_documents c:\output\cases
```

### 3. **Results**
- Cases are saved to JSON automatically
- Default output folder: `./output`
- File naming: `cases_YYYYMMDD_HHmmss.json`

## Supported File Types

| Type | Extensions | Processor |
|------|-----------|-----------|
| Email | .eml, .msg | EmailProcessor |
| PDF | .pdf | PdfProcessor |
| Text | .txt, .text | LiteratureProcessor |
| Any Text File | * | LiteratureProcessor (if readable) |

## Document Format

For best extraction, structure text documents with these sections:

```
PATIENT INFORMATION
-------------------
Patient ID: PAT-2025-001
Age: 52
Gender: Female
Weight: 68 kg

MEDICATION INFORMATION
----------------------
Medication Name: Lisinopril
Dosage: 10mg
Frequency: Once daily
Batch Number: BATCH-20251101-002

ADVERSE EVENT DETAILS
---------------------
Event Name: Severe Rash
Severity: Moderate
Seriousness: Serious
Description: [Description of event]

REPORTER INFORMATION
-------------------
Reporter: Dr. James Mitchell
Reporter Role: Physician
Reporter Contact: j.mitchell@medical.com

CAUSALITY ASSESSMENT
-------------------
Causality: Probable
Relatedness: High
Preventability: Not preventable

NARRATIVE SUMMARY
-----------------
[Comprehensive narrative]

FOLLOW-UP ACTIONS
-----------------
1. Action Type: Pulmonology Consultation
2. Action Type: Allergy Testing
```

## Example Usage

### Single File
```powershell
dotnet run c:\Work\dotnet\sample_documents\adverse_event_report.txt
```

### Multiple Files
```powershell
dotnet run c:\Work\dotnet\sample_documents c:\Work\dotnet\output
```

**Output:**
```
📁 Processing folder: c:\Work\dotnet\sample_documents
Found 2 file(s)

Processing: adverse_event_report.txt...
  ✓ Case created: 7682ced7-fe93-4f6b-a605-6d3ed581e52f

Processing: case_notification.txt...
  ✗ Error processing case_notification.txt: Case validation failed

Successfully processed 1/2 files

💾 Saving results...
✓ Results saved to: c:\Work\dotnet\output\cases_20251211_143807.json
```

## Generated JSON Output

The extracted cases are automatically saved as structured JSON:

```json
[
  {
    "caseId": "7682ced7-fe93-4f6b-a605-6d3ed581e52f",
    "caseStatus": "New",
    "dateOfIntake": "2025-12-11T09:08:07.618Z",
    "sourceDocument": {
      "sourceType": "Literature",
      "sourceFileName": "adverse_event_report.txt",
      "extractionMethod": "NLP"
    },
    "patientInformation": {
      "patientId": "PAT-2025-001",
      "age": 52,
      "gender": "Female",
      "weight": 68
    },
    "medication": {
      "medicationName": "Lisinopril",
      "dosage": "10mg",
      "frequency": "Once daily"
    },
    "adverseEvent": {
      "eventName": "Severe Persistent Dry Cough",
      "severity": "Moderate",
      "seriousness": "Serious"
    },
    "metadata": {
      "createdBy": "Document Processor",
      "createdAt": "2025-12-11T09:08:07.618Z",
      "version": 1
    }
  }
]
```

## Validation

The system validates that each case has:
- ✅ Adverse event information (required)
- ✅ Medication details (required)
- ✅ Patient information (required)

Cases missing required fields will be skipped with error messages.

## Sample Documents

Sample test documents are located in:
```
c:\Work\dotnet\sample_documents\
```

- `adverse_event_report.txt` - Full adverse event report (✓ Processed successfully)
- `case_notification.txt` - Email format case notification (Medication name needed)

## Next Steps

1. **Add more sample documents** to `c:\Work\dotnet\sample_documents\`
2. **Implement PDF processor** for real PDF document handling
3. **Implement Email processor** for .eml/.msg files
4. **Add NLP enhancements** for better entity extraction
5. **Create API endpoints** to expose as REST service
6. **Add database persistence** instead of in-memory storage
