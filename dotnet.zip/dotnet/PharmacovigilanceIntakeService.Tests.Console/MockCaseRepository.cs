using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using PharmacovigilanceIntakeService.Models;
using PharmacovigilanceIntakeService.Interfaces;

namespace PharmacovigilanceIntakeService.Tests.Console
{
    /// <summary>
    /// In-memory mock repository for testing
    /// </summary>
    public class MockCaseRepository : ICaseRepository
    {
        private readonly Dictionary<string, PharmacovigilanceCase> _cases = new();

        public Task SaveAsync(PharmacovigilanceCase caseData)
        {
            if (caseData == null)
                throw new ArgumentNullException(nameof(caseData));

            _cases[caseData.CaseId] = caseData;
            System.Console.WriteLine($"  ✓ Case saved: {caseData.CaseId}");
            return Task.CompletedTask;
        }

        public Task<PharmacovigilanceCase> GetByIdAsync(string caseId)
        {
            if (string.IsNullOrWhiteSpace(caseId))
                throw new ArgumentException("Case ID cannot be null", nameof(caseId));

            if (_cases.TryGetValue(caseId, out var caseData))
            {
                System.Console.WriteLine($"  ✓ Case retrieved: {caseId}");
                return Task.FromResult(caseData);
            }

            System.Console.WriteLine($"  ✗ Case not found: {caseId}");
            return Task.FromResult<PharmacovigilanceCase>(null!);
        }

        public Task UpdateAsync(PharmacovigilanceCase caseData)
        {
            if (caseData == null)
                throw new ArgumentNullException(nameof(caseData));

            if (!_cases.ContainsKey(caseData.CaseId))
            {
                System.Console.WriteLine($"  ✗ Case not found for update: {caseData.CaseId}");
                throw new KeyNotFoundException($"Case {caseData.CaseId} not found");
            }

            _cases[caseData.CaseId] = caseData;
            System.Console.WriteLine($"  ✓ Case updated: {caseData.CaseId}");
            return Task.CompletedTask;
        }

        public Task DeleteAsync(string caseId)
        {
            if (string.IsNullOrWhiteSpace(caseId))
                throw new ArgumentException("Case ID cannot be null", nameof(caseId));

            if (_cases.Remove(caseId))
            {
                System.Console.WriteLine($"  ✓ Case deleted: {caseId}");
            }
            else
            {
                System.Console.WriteLine($"  ✗ Case not found for deletion: {caseId}");
            }

            return Task.CompletedTask;
        }

        public int GetCaseCount() => _cases.Count;

        public IEnumerable<PharmacovigilanceCase> GetAllCases() => _cases.Values;
    }
}
