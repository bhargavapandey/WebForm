using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PharmacovigilanceIntakeService.Models;
using PharmacovigilanceIntakeService.Services;
using PharmacovigilanceIntakeService.DocumentProcessing;

namespace PharmacovigilanceIntakeService.Tests.Console
{
    class Program
    {
        static async Task Main(string[] args)
        {
            System.Console.WriteLine("\n╔════════════════════════════════════════════════════════════════╗");
            System.Console.WriteLine("║     Pharmacovigilance Case Intake Service - Console Test       ║");
            System.Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");

            try
            {
                // Initialize mock repository
                var repository = new MockCaseRepository();
                var caseService = new CaseIntakeService(repository);

                // Test 1: Create a sample case
                System.Console.WriteLine("📋 TEST 1: Create Sample Case");
                System.Console.WriteLine("─────────────────────────────────────────────");
                var sampleCase = CreateSampleCase();
                var createdCase = await caseService.CreateCaseAsync(sampleCase, "Dr. Smith");
                System.Console.WriteLine($"Case ID: {createdCase.CaseId}");
                System.Console.WriteLine($"Status: {createdCase.CaseStatus}");
                System.Console.WriteLine($"Date: {createdCase.DateOfIntake:g}\n");

                // Test 2: Retrieve the case
                System.Console.WriteLine("🔍 TEST 2: Retrieve Case");
                System.Console.WriteLine("─────────────────────────────────────────────");
                var retrievedCase = await caseService.GetCaseAsync(createdCase.CaseId);
                if (retrievedCase != null)
                {
                    System.Console.WriteLine($"Patient ID: {retrievedCase.PatientInformation?.PatientId}");
                    System.Console.WriteLine($"Event: {retrievedCase.AdverseEvent?.EventName}");
                    System.Console.WriteLine($"Medication: {retrievedCase.Medication?.MedicationName}\n");
                }

                // Test 3: Update the case
                System.Console.WriteLine("✏️  TEST 3: Update Case Status");
                System.Console.WriteLine("─────────────────────────────────────────────");
                retrievedCase!.CaseStatus = CaseStatus.UnderReview;
                retrievedCase.Assessments = new CaseAssessments
                {
                    Causality = CausalityAssessment.Probable,
                    Relatedness = "High",
                    Preventability = "Not preventable"
                };
                var updatedCase = await caseService.UpdateCaseAsync(retrievedCase, "Dr. Johnson");
                System.Console.WriteLine($"New Status: {updatedCase.CaseStatus}");
                System.Console.WriteLine($"Causality: {updatedCase.Assessments?.Causality}");
                System.Console.WriteLine($"Version: {updatedCase.Metadata?.Version}\n");

                // Test 4: Validate a case
                System.Console.WriteLine("✅ TEST 4: Case Validation");
                System.Console.WriteLine("─────────────────────────────────────────────");
                bool isValid = caseService.ValidateCase(retrievedCase);
                System.Console.WriteLine($"Case Valid: {isValid}");
                if (!isValid)
                {
                    var errors = caseService.GetValidationErrors(retrievedCase);
                    foreach (var error in errors)
                        System.Console.WriteLine($"  - {error}");
                }
                System.Console.WriteLine();

                // Test 5: Create invalid case and test validation
                System.Console.WriteLine("❌ TEST 5: Validate Invalid Case");
                System.Console.WriteLine("─────────────────────────────────────────────");
                var invalidCase = new PharmacovigilanceCase
                {
                    CaseStatus = CaseStatus.New
                    // Missing required fields
                };
                bool isInvalid = caseService.ValidateCase(invalidCase);
                System.Console.WriteLine($"Case Valid: {isInvalid}");
                var validationErrors = caseService.GetValidationErrors(invalidCase);
                System.Console.WriteLine($"Errors found: {validationErrors.Length}");
                foreach (var error in validationErrors)
                    System.Console.WriteLine($"  - {error}\n");

                // Test 6: Document Processing
                System.Console.WriteLine("📄 TEST 6: Document Processors");
                System.Console.WriteLine("─────────────────────────────────────────────");
                var emailProcessor = new EmailProcessor();
                var pdfProcessor = new PdfProcessor();
                var literatureProcessor = new LiteratureProcessor();

                System.Console.WriteLine($"Email Processor Supports 'Email': {emailProcessor.CanProcess("Email")}");
                System.Console.WriteLine($"PDF Processor Supports 'PDF': {pdfProcessor.CanProcess("PDF")}");
                System.Console.WriteLine($"Literature Processor Supports 'TXT': {literatureProcessor.CanProcess("TXT")}");
                System.Console.WriteLine($"Email Processor Supports 'PDF': {emailProcessor.CanProcess("PDF")}\n");

                // Test 7: Create multiple cases
                System.Console.WriteLine("📊 TEST 7: Create Multiple Cases");
                System.Console.WriteLine("─────────────────────────────────────────────");
                for (int i = 0; i < 3; i++)
                {
                    var multiCase = CreateSampleCase();
                    multiCase.Medication!.MedicationName = $"Medication {i + 1}";
                    await caseService.CreateCaseAsync(multiCase, "Dr. Admin");
                }
                System.Console.WriteLine($"Total cases in repository: {repository.GetCaseCount()}\n");

                // Test 8: Display all cases summary
                System.Console.WriteLine("📋 TEST 8: All Cases Summary");
                System.Console.WriteLine("─────────────────────────────────────────────");
                var allCases = repository.GetAllCases();
                int caseNum = 1;
                foreach (var c in allCases)
                {
                    System.Console.WriteLine($"{caseNum}. ID: {c.CaseId}");
                    System.Console.WriteLine($"   Status: {c.CaseStatus}");
                    System.Console.WriteLine($"   Medication: {c.Medication?.MedicationName}");
                    System.Console.WriteLine($"   Event: {c.AdverseEvent?.EventName}\n");
                    caseNum++;
                }

                System.Console.WriteLine("╔════════════════════════════════════════════════════════════════╗");
                System.Console.WriteLine("║                    ✓ All Tests Completed                     ║");
                System.Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");
            }
            catch (Exception ex)
            {
                System.Console.ForegroundColor = ConsoleColor.Red;
                System.Console.WriteLine($"\n❌ Error: {ex.Message}");
                System.Console.ResetColor();
            }
        }

        static PharmacovigilanceCase CreateSampleCase()
        {
            return new PharmacovigilanceCase
            {
                CaseStatus = CaseStatus.New,
                SourceDocument = new SourceDocument
                {
                    SourceType = "Email",
                    SourceFileName = "patient_report.eml",
                    ExtractionMethod = "NLP"
                },
                PatientInformation = new PatientInformation
                {
                    PatientId = $"PAT-{Guid.NewGuid().ToString().Substring(0, 8)}",
                    Age = 45,
                    Gender = "Male",
                    Weight = 75.5,
                    MedicalHistory = new List<string>
                    {
                        "Hypertension",
                        "Type 2 Diabetes",
                        "Hyperlipidemia"
                    }
                },
                AdverseEvent = new AdverseEvent
                {
                    EventName = "Severe Rash",
                    EventDate = DateTime.Now.AddDays(-5),
                    Severity = SeverityLevel.Moderate,
                    Seriousness = "Serious",
                    Outcome = EventOutcome.Recovering,
                    Description = "Patient developed severe allergic rash following medication administration"
                },
                Medication = new Medication
                {
                    MedicationName = "Amoxicillin",
                    ActiveIngredient = "Amoxicillin Trihydrate",
                    Dosage = "500mg",
                    Frequency = "Three times daily",
                    Route = "Oral",
                    StartDate = DateTime.Now.AddDays(-10),
                    EndDate = DateTime.Now.AddDays(-2),
                    BatchNumber = "BATCH-20241201-001",
                    Indication = "Bacterial Infection"
                },
                ConcomitantMedications = new List<Medication>
                {
                    new Medication
                    {
                        MedicationName = "Metformin",
                        Dosage = "500mg",
                        Frequency = "Twice daily"
                    }
                },
                ReporterInformation = new ReporterInformation
                {
                    ReporterName = "Jane Doe",
                    ReporterRole = "Physician",
                    ReporterContact = "jane.doe@hospital.com"
                },
                NarrativeSummary = "45-year-old male patient presented with severe allergic rash after starting Amoxicillin treatment. Rash appeared within 24 hours of first dose. Patient has history of drug allergies but not specifically to Amoxicillin.",
                FollowUpActions = new List<FollowUpAction>
                {
                    new FollowUpAction
                    {
                        ActionType = "Medical Assessment",
                        ActionDescription = "Dermatology consultation required",
                        DueDate = DateTime.Now.AddDays(7),
                        AssignedTo = "Dr. Smith",
                        Status = "Pending"
                    }
                }
            };
        }
    }
}
