# Pharmacovigilance Case Extraction & Creation - Detailed Technical Guide

## Table of Contents
1. [System Architecture](#system-architecture)
2. [End-to-End Workflow](#end-to-end-workflow)
3. [Document Processing Pipeline](#document-processing-pipeline)
4. [Data Extraction Mechanisms](#data-extraction-mechanisms)
5. [Case Creation Process](#case-creation-process)
6. [Validation & Error Handling](#validation--error-handling)
7. [JSON Serialization](#json-serialization)
8. [Example Scenarios](#example-scenarios)
9. [Technical Implementation Details](#technical-implementation-details)

---

## System Architecture

### High-Level Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    INPUT LAYER                              │
│  (Email, PDF, Text Documents from unstructured sources)     │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              DOCUMENT DETECTION & ROUTING                   │
│  Analyzes file extension and content type                   │
└────────────────────┬────────────────────────────────────────┘
                     │
         ┌───────────┼───────────┐
         │           │           │
         ▼           ▼           ▼
    ┌────────┐  ┌────────┐  ┌──────────┐
    │ Email  │  │  PDF   │  │Literature│
    │Process │  │Process │  │Processor │
    └────┬───┘  └────┬───┘  └──────┬───┘
         │           │             │
         └───────────┼─────────────┘
                     │
                     ▼
    ┌─────────────────────────────────┐
    │  DATA EXTRACTION & PARSING      │
    │  (Regex-based field extraction) │
    └────────┬────────────────────────┘
             │
             ▼
    ┌─────────────────────────────────┐
    │  CASE MODEL POPULATION          │
    │  (Structured Case Object)       │
    └────────┬────────────────────────┘
             │
             ▼
    ┌─────────────────────────────────┐
    │  VALIDATION ENGINE              │
    │  (Required fields check)        │
    └────────┬────────────────────────┘
             │
         ┌───┴────┐
         │        │
      VALID    INVALID
         │        │
         ▼        ▼
    ┌────────┐  ┌──────────┐
    │ CREATE │  │  SKIP &  │
    │ CASE   │  │  LOG ERR │
    └────┬───┘  └──────────┘
         │
         ▼
    ┌─────────────────────────────────┐
    │  METADATA ASSIGNMENT            │
    │  (Timestamps, Creator, Version) │
    └────────┬────────────────────────┘
             │
             ▼
    ┌─────────────────────────────────┐
    │  PERSISTENCE (Repository)       │
    │  (In-memory or Database)        │
    └────────┬────────────────────────┘
             │
             ▼
    ┌─────────────────────────────────┐
    │  JSON SERIALIZATION             │
    │  (Convert to JSON format)       │
    └────────┬────────────────────────┘
             │
             ▼
┌─────────────────────────────────────────────────────────────┐
│            OUTPUT: JSON Case File                           │
│   (cases_YYYYMMDD_HHmmss.json)                             │
└─────────────────────────────────────────────────────────────┘
```

### Component Responsibilities

| Component | Responsibility | Technology |
|-----------|-----------------|------------|
| **Document Processor** | Route & read documents | MimeKit, PdfSharp, File I/O |
| **Extractor** | Parse content & extract fields | Regex, string manipulation |
| **Case Model** | Hold structured case data | C# classes with JSON attributes |
| **Validator** | Check required fields | Business logic rules |
| **Repository** | Store cases | In-memory Dictionary |
| **Serializer** | Convert to JSON | System.Text.Json |

---

## End-to-End Workflow

### Step-by-Step Process

#### **PHASE 1: INITIALIZATION**
```
User Input: dotnet run <path> [output_folder]
                ↓
Program.Main() execution
                ↓
Initialize Services:
  ├─ MockCaseRepository (in-memory storage)
  ├─ CaseIntakeService (business logic)
  ├─ EmailProcessor
  ├─ PdfProcessor
  └─ LiteratureProcessor
                ↓
Validate Input Path (file or folder)
                ↓
Create Output Directory (if doesn't exist)
```

#### **PHASE 2: DOCUMENT DISCOVERY**
```
If Single File:
  └─ Process immediately

If Folder:
  ├─ Directory.GetFiles(path, "*.*", SearchOption.AllDirectories)
  ├─ Get all files (including subdirectories)
  └─ Create processing queue
                ↓
Display: "Found X file(s)"
```

#### **PHASE 3: DOCUMENT ROUTING**
```
For Each File:
  ├─ Extract file extension
  ├─ Determine processor type:
  │   ├─ .eml, .msg → EmailProcessor
  │   ├─ .pdf → PdfProcessor
  │   ├─ .txt → LiteratureProcessor
  │   └─ [unknown] → Try text detection
  └─ Route to appropriate processor
```

#### **PHASE 4: DOCUMENT PROCESSING**
```
[EmailProcessor Example]
  ├─ MimeMessage.Load(filePath)
  ├─ Extract email headers (From, Subject, Date)
  ├─ Extract body (text or HTML→text)
  ├─ Extract attachments metadata
  └─ Return combined text content
                ↓
[PdfProcessor Example]
  ├─ PdfReader.Open(filePath)
  ├─ Iterate through pages
  ├─ Extract text content
  ├─ Handle extraction errors gracefully
  └─ Return combined text content
                ↓
[LiteratureProcessor Example]
  ├─ File.ReadAllText(filePath)
  └─ Return text content
                ↓
Process Result: String content ready for parsing
```

#### **PHASE 5: DATA EXTRACTION**
```
Input: Raw text content from document

Extract via Regex Patterns:
  ├─ Patient Information
  │   ├─ Patient ID: Regex.Match(content, @"Patient ID:\s*([A-Za-z0-9\-]+)")
  │   ├─ Age: Regex.Match(content, @"Age:\s*(\d+)")
  │   ├─ Gender: Regex.Match(content, @"Gender:\s*(Male|Female|...)")
  │   └─ Weight: Regex.Match(content, @"Weight:\s*([\d.]+)\s*kg")
  │
  ├─ Medication Information
  │   ├─ Name: Regex.Match(content, @"Medication Name:\s*([^\n]+)")
  │   ├─ Dosage: Regex.Match(content, @"Dosage:\s*([^\n]+)")
  │   ├─ Frequency: Regex.Match(content, @"Frequency:\s*([^\n]+)")
  │   ├─ Batch: Regex.Match(content, @"Batch Number:\s*([^\n]+)")
  │   └─ Indication: Regex.Match(content, @"Indication:\s*([^\n]+)")
  │
  ├─ Adverse Event
  │   ├─ Name: Regex.Match(content, @"Event Name:\s*([^\n]+)")
  │   ├─ Severity: Parse enum from "Mild|Moderate|Severe|..."
  │   ├─ Seriousness: Detect if "Serious" keyword present
  │   └─ Description: Extract multi-line text block
  │
  ├─ Reporter Information
  │   ├─ (Email) Use message.From[0] headers
  │   ├─ Name: Regex extraction or email header
  │   ├─ Role: Regex.Match(content, @"Reporter Role:\s*([^\n]+)")
  │   └─ Contact: Regex extraction or email address
  │
  ├─ Causality Assessment
  │   ├─ Causality: Parse enum (Certain|Probable|Possible|...)
  │   ├─ Relatedness: Extract text value
  │   └─ Preventability: Extract text value
  │
  └─ Follow-Up Actions
      ├─ Split by numbered list patterns: (\d+)\.\s*Action Type:
      └─ Extract each action type

Output: Extracted data dictionary
```

#### **PHASE 6: CASE OBJECT CREATION**
```
Create new PharmacovigilanceCase instance:
  ├─ Set CaseId = Guid.NewGuid().ToString()
  ├─ Set CaseStatus = CaseStatus.New
  ├─ Set DateOfIntake = DateTime.UtcNow
  ├─ Assign SourceDocument
  │   └─ SourceType, SourceFileName, ExtractionMethod
  ├─ Assign PatientInformation (from extracted data)
  ├─ Assign AdverseEvent (from extracted data)
  ├─ Assign Medication (from extracted data)
  ├─ Assign ReporterInformation (from extracted data)
  ├─ Assign NarrativeSummary (from extracted data)
  ├─ Assign CaseAssessments (from extracted data)
  ├─ Assign FollowUpActions (from extracted data)
  └─ Leave Attachments = empty list (can be populated later)

Output: Fully initialized PharmacovigilanceCase object
```

#### **PHASE 7: VALIDATION**
```
CaseIntakeService.ValidateCase(caseData):
  
Check Required Fields:
  ├─ AdverseEvent != null
  │   └─ If null: Add error "Adverse event is required"
  ├─ AdverseEvent.EventName != empty
  │   └─ If empty: Add error "Adverse event name is required"
  ├─ Medication != null
  │   └─ If null: Add error "Medication is required"
  ├─ Medication.MedicationName != empty
  │   └─ If empty: Add error "Medication name is required"
  ├─ Medication.Dosage != empty
  │   └─ If empty: Add error "Medication dosage is required"
  ├─ PatientInformation != null
  │   └─ If null: Add error "Patient information is required"
  └─ CaseStatus is valid enum
      └─ If invalid: Add error "Invalid case status"

Validation Result:
  ├─ If errors.Length == 0
  │   └─ Return true (VALID)
  └─ Else
      └─ Return false (INVALID)

Output: Boolean validation result + error list
```

#### **PHASE 8: CASE CREATION**
```
If Validation = PASS:
  
  CaseIntakeService.CreateCaseAsync(caseData, createdBy):
    ├─ Create Metadata object
    │   ├─ CreatedBy = "Document Processor"
    │   ├─ CreatedAt = DateTime.UtcNow
    │   └─ Version = 1
    ├─ Assign Metadata to case
    ├─ Call repository.SaveAsync(caseData)
    │   └─ Add to in-memory dictionary
    ├─ Return created case object
    └─ Display: "✓ Case created: [CaseId]"

Else If Validation = FAIL:
  └─ Display: "✗ Error processing [filename]: [error messages]"
  └─ Skip file and continue to next
```

#### **PHASE 9: JSON SERIALIZATION & OUTPUT**
```
After All Files Processed:

Collect all successfully created cases:
  └─ List<PharmacovigilanceCase> processedCases

Serialize to JSON:
  ├─ Configure JsonSerializerOptions:
  │   ├─ WriteIndented = true (pretty print)
  │   ├─ DefaultIgnoreCondition = WhenWritingNull
  │   └─ PropertyNamingPolicy = CamelCase
  ├─ Call JsonSerializer.Serialize(cases, options)
  └─ Get JSON string output

Write to File:
  ├─ Create filename: cases_YYYYMMDD_HHmmss.json
  ├─ Build full path: Path.Combine(outputFolder, filename)
  ├─ File.WriteAllText(jsonOutputPath, jsonContent)
  └─ Display: "✓ Results saved to: [filepath]"

Output File Format:
[
  {
    "caseId": "uuid-string",
    "caseStatus": "New",
    "dateOfIntake": "2025-12-11T09:12:32.591Z",
    "sourceDocument": { ... },
    "patientInformation": { ... },
    "medication": { ... },
    "adverseEvent": { ... },
    "reporterInformation": { ... },
    "assessments": { ... },
    "followUpActions": [...],
    "metadata": { ... }
  },
  { ... next case ... }
]
```

---

## Document Processing Pipeline

### Email Processing Pipeline

```
INPUT: adverse_event_email.eml
│
├─ [1] Load Email File
│       MimeMessage.Load(filePath) → MimeMessage object
│
├─ [2] Extract Components
│   ├─ message.From[0] → Sender info
│   ├─ message.Subject → Email subject
│   ├─ message.TextBody or message.HtmlBody → Body content
│   └─ message.Attachments → File references
│
├─ [3] Combine into Text
│       Subject: [value]
│       From: [sender]
│       [body content]
│       Attachments: [list]
│
├─ [4] Parse Text with Regex
│       Apply 20+ regex patterns to extract:
│       - Patient fields
│       - Medication details
│       - Event information
│       - Reporter data
│       - Assessment values
│
├─ [5] Populate Case Object
│       Create PharmacovigilanceCase with extracted data
│
├─ [6] Set Source Metadata
│       sourceType: "Email"
│       sourceFileName: "adverse_event_email.eml"
│       extractionMethod: "NLP"
│
└─ OUTPUT: Structured Case Object
```

### PDF Processing Pipeline

```
INPUT: clinical_report.pdf
│
├─ [1] Open PDF File
│       PdfReader.Open(filePath, PdfDocumentOpenMode.Import)
│
├─ [2] Iterate Pages
│       For each page in document.Pages:
│           ├─ Access page.Contents
│           ├─ Extract text stream
│           └─ Append to content buffer
│
├─ [3] Handle Complex PDFs
│       ├─ If standard extraction fails
│       ├─ Return fallback message
│       └─ Log warning to user
│
├─ [4] Combine Page Content
│       Single text string of all pages
│
├─ [5] Parse Text with Regex
│       Same regex patterns as email/text
│
├─ [6] Populate Case Object
│       Create PharmacovigilanceCase
│
├─ [7] Set Source Metadata
│       sourceType: "PDF"
│       sourceFileName: "clinical_report.pdf"
│       extractionMethod: "Text Extraction"
│
└─ OUTPUT: Structured Case Object

Note: For complex PDFs with images/scans, consider:
   - Tesseract OCR
   - Google Cloud Vision API
   - Azure Computer Vision
```

### Text Processing Pipeline

```
INPUT: adverse_event_report.txt
│
├─ [1] Read File
│       File.ReadAllText(filePath) → String content
│
├─ [2] Apply Regex Extraction
│       Pattern matching for all fields
│
├─ [3] Parse Multi-line Sections
│       ├─ Patient Information section
│       ├─ Medication Information section
│       ├─ Adverse Event Details section
│       ├─ Reporter Information section
│       ├─ Narrative Summary section
│       └─ Follow-up Actions section
│
├─ [4] Handle Missing Fields
│       ├─ Default empty strings for optional fields
│       ├─ Mark null for completely missing sections
│       └─ Collect errors for validation phase
│
├─ [5] Populate Case Object
│       Create PharmacovigilanceCase
│
├─ [6] Set Source Metadata
│       sourceType: "Literature"
│       sourceFileName: "adverse_event_report.txt"
│       extractionMethod: "NLP"
│
└─ OUTPUT: Structured Case Object
```

---

## Data Extraction Mechanisms

### Regex Pattern Library

#### Patient Information Extraction

```csharp
// Extract Patient ID
Pattern: @"Patient ID:\s*([A-Za-z0-9\-]+)"
Example: "Patient ID: PAT-2025-001" → "PAT-2025-001"

// Extract Age
Pattern: @"Age:\s*(\d+)"
Example: "Age: 52" → 52

// Extract Gender
Pattern: @"Gender:\s*(Male|Female|Other)"
Example: "Gender: Female" → "Female"

// Extract Weight
Pattern: @"Weight:\s*([\d.]+)\s*kg"
Example: "Weight: 68 kg" → 68.0

Implementation:
var ageMatch = Regex.Match(content, @"Age:\s*(\d+)", RegexOptions.IgnoreCase);
if (ageMatch.Success && int.TryParse(ageMatch.Groups[1].Value, out int age))
    patientInfo.Age = age;
```

#### Medication Information Extraction

```csharp
// Extract Medication Name
Pattern: @"Medication Name:\s*([^\n]+)"
Example: "Medication Name: Lisinopril" → "Lisinopril"

// Extract Dosage
Pattern: @"Dosage:\s*([^\n]+)"
Example: "Dosage: 10mg" → "10mg"

// Extract Batch Number
Pattern: @"Batch Number:\s*([^\n]+)"
Example: "Batch Number: BATCH-20251101-002" → "BATCH-20251101-002"

Implementation:
var medNameMatch = Regex.Match(content, @"Medication Name:\s*([^\n]+)", RegexOptions.IgnoreCase);
if (medNameMatch.Success)
    medication.MedicationName = medNameMatch.Groups[1].Value.Trim();
```

#### Adverse Event Extraction

```csharp
// Extract Event Name
Pattern: @"Event Name:\s*([^\n]+)"
Example: "Event Name: Severe Rash" → "Severe Rash"

// Extract Severity (Enum)
Pattern: @"Severity:\s*(Mild|Moderate|Severe|Life-threatening|Fatal)"
Example: "Severity: Moderate" → SeverityLevel.Moderate
Enum Parse: Enum.TryParse<SeverityLevel>(value, true, out var severity)

// Extract Description (Multi-line)
Pattern: @"Description:\s*([^\n]+(?:\n(?!.*:).*)*)"
Example: Multi-line text block until next field marker

Implementation:
var severityMatch = Regex.Match(content, @"Severity:\s*(Mild|...)", RegexOptions.IgnoreCase);
if (severityMatch.Success)
{
    if (Enum.TryParse<SeverityLevel>(severityMatch.Groups[1].Value, true, out var severity))
        adverseEvent.Severity = severity;
}
```

#### Assessment Extraction

```csharp
// Extract Causality (Enum)
Pattern: @"Causality:\s*(Certain|Probable|Possible|Unlikely|Unrelated|Unknown)"
Enum: CausalityAssessment (converted with Enum.TryParse)

// Extract Relatedness (Free text)
Pattern: @"Relatedness:\s*([^\n]+)"
Example: "Relatedness: High (ACE inhibitor dry cough is known side effect)"

// Extract Preventability (Free text)
Pattern: @"Preventability:\s*([^\n]+)"
Example: "Preventability: Not preventable"

Implementation:
var causalityMatch = Regex.Match(content, @"Causality:\s*(Certain|Probable|...)", RegexOptions.IgnoreCase);
if (causalityMatch.Success)
{
    if (Enum.TryParse<CausalityAssessment>(causalityMatch.Groups[1].Value, true, out var causality))
        assessments.Causality = causality;
}
```

#### Follow-Up Actions Extraction

```csharp
// Extract Action Type List
Pattern: @"(\d+)\.\s*(?:Action Type|Type):\s*([^\n]+)"
Examples:
  "1. Action Type: Pulmonology Consultation" → "Pulmonology Consultation"
  "2. Action Type: Allergy Testing" → "Allergy Testing"

Implementation:
var actionMatches = Regex.Matches(content, @"(\d+)\.\s*(?:Action Type|Type):\s*([^\n]+)", RegexOptions.IgnoreCase);
foreach (Match match in actionMatches)
{
    var action = new FollowUpAction
    {
        ActionType = match.Groups[2].Value.Trim(),
        Status = "Pending"
    };
    followUpActions.Add(action);
}
```

### Pattern Matching Strategy

```
RegexOptions.IgnoreCase
  ├─ Handles variations in document formatting
  ├─ "Patient ID" or "patient id" or "PATIENT ID"
  └─ Increases extraction success rate

Grouping with Parentheses
  ├─ Captures desired data
  ├─ Groups[0] = entire match
  ├─ Groups[1] = first capture group
  └─ Groups[2] = second capture group, etc.

Anchoring Patterns
  ├─ ^ = start of line
  ├─ $ = end of line
  ├─ \b = word boundary
  ├─ [^\n]+ = any char except newline
  └─ Prevents partial/incorrect matches

Handling Failures
  ├─ if (match.Success) before accessing Groups
  ├─ Graceful degradation if field not found
  ├─ Optional fields default to null
  ├─ Required fields trigger validation error
  └─ Process continues for other fields
```

---

## Case Creation Process

### Step 1: Instantiation

```csharp
public PharmacovigilanceCase()
{
    CaseId = Guid.NewGuid().ToString();           // Unique identifier
    DateOfIntake = DateTime.UtcNow;               // Timestamp
    CaseStatus = CaseStatus.New;                  // Initial status
    ConcomitantMedications = new List<Medication>();  // Empty collections
    FollowUpActions = new List<FollowUpAction>();
    Attachments = new List<Attachment>();
}
```

### Step 2: Population

```
Create CaseData object
  ├─ Initialize with new PharmacovigilanceCase()
  ├─ Set SourceDocument
  │   ├─ sourceType = "Email" | "PDF" | "Literature"
  │   ├─ sourceFileName = Path.GetFileName(filePath)
  │   └─ extractionMethod = "NLP" | "Text Extraction" | "OCR"
  ├─ Assign PatientInformation (extracted data)
  ├─ Assign AdverseEvent (extracted data)
  ├─ Assign Medication (extracted data)
  ├─ Assign ConcomitantMedications[] (extracted data)
  ├─ Assign ReporterInformation (extracted data)
  ├─ Assign NarrativeSummary (extracted data)
  ├─ Assign Assessments (extracted data)
  └─ Assign FollowUpActions[] (extracted data)
```

### Step 3: Service Method Invocation

```csharp
public async Task<PharmacovigilanceCase> CreateCaseAsync(
    PharmacovigilanceCase caseData, 
    string createdBy)
{
    // 1. Null checks
    if (caseData == null)
        throw new ArgumentNullException(nameof(caseData));
    if (string.IsNullOrWhiteSpace(createdBy))
        throw new ArgumentException("Created by user name required", nameof(createdBy));
    
    // 2. Validation
    if (!ValidateCase(caseData))
    {
        var errors = GetValidationErrors(caseData);
        throw new ValidationException($"Case validation failed: {string.Join(", ", errors)}");
    }
    
    // 3. Set Metadata
    caseData.Metadata = new CaseMetadata
    {
        CreatedBy = createdBy,
        CreatedAt = DateTime.UtcNow,
        Version = 1
    };
    
    // 4. Generate IDs
    caseData.CaseId = Guid.NewGuid().ToString();
    caseData.DateOfIntake = DateTime.UtcNow;
    
    // 5. Persist
    await _repository.SaveAsync(caseData);
    
    // 6. Return
    return caseData;
}
```

### Step 4: Persistence

```csharp
public Task SaveAsync(PharmacovigilanceCase caseData)
{
    if (caseData == null)
        throw new ArgumentNullException(nameof(caseData));
    
    // Add to in-memory dictionary
    _cases[caseData.CaseId] = caseData;
    
    // In production, would save to database:
    // await _dbContext.Cases.AddAsync(caseData);
    // await _dbContext.SaveChangesAsync();
    
    return Task.CompletedTask;
}
```

---

## Validation & Error Handling

### Validation Rules

```
Required Fields Check:
┌─────────────────────────────────────────────┐
│ FIELD                    │ VALIDATION       │
├──────────────────────────┼──────────────────┤
│ CaseStatus               │ Must be valid    │
│ AdverseEvent             │ Cannot be null   │
│ AdverseEvent.EventName   │ Cannot be empty  │
│ Medication               │ Cannot be null   │
│ Medication.Name          │ Cannot be empty  │
│ Medication.Dosage        │ Cannot be empty  │
│ PatientInformation       │ Cannot be null   │
└─────────────────────────────────────────────┘

All other fields are optional (can be null or empty)
```

### Error Handling Flow

```
Try Process Document
  ├─ If DocumentNotFoundException
  │   └─ Display: "❌ Error: Path not found"
  ├─ If ValidationException
  │   └─ Display: "✗ Case validation failed: [errors]"
  ├─ If InvalidOperationException
  │   └─ Display: "✗ Error processing [file]: [message]"
  └─ If Any Other Exception
      └─ Display: "❌ Error: [message]"

Continue Processing Next File
  └─ Don't stop entire batch on single failure
```

### Validation Error Messages

```
Validation Errors Collected:
├─ "Adverse event is required"
├─ "Adverse event name is required"
├─ "Medication is required"
├─ "Medication name is required"
├─ "Medication dosage is required"
├─ "Patient information is required"
└─ "Invalid case status"

All errors concatenated: 
  "Case validation failed: Error1, Error2, Error3"

User sees: 
  ✗ Error processing file.txt: Adverse event is required, Medication is required
```

---

## JSON Serialization

### Serialization Configuration

```csharp
var options = new JsonSerializerOptions
{
    // 1. Pretty Print
    WriteIndented = true,
    
    // 2. Null Handling
    DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    // Don't include null properties in output
    
    // 3. Property Naming
    PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
    // C# CaseId → JSON caseId
    
    // 4. Converters for custom types (built-in for enums)
};

string json = JsonSerializer.Serialize(cases, options);
File.WriteAllText(outputPath, json);
```

### Output Format

```json
[
  {
    "caseId": "9228d079-830a-4bb5-b2a8-504ac900049a",
    "caseStatus": "New",
    "dateOfIntake": "2025-12-11T09:12:02.6816905Z",
    "sourceDocument": {
      "sourceType": "Email",
      "sourceFileName": "adverse_event_email.eml",
      "extractionMethod": "NLP"
    },
    "patientInformation": {
      "patientId": "PAT-2025-005",
      "age": 67,
      "gender": "Male",
      "weight": 82.5,
      "medicalHistory": []
    },
    "adverseEvent": {
      "eventName": "Severe Bleeding Episode",
      "eventDate": null,
      "severity": "Severe",
      "seriousness": "Serious",
      "outcome": null,
      "description": "Patient presented to ED..."
    },
    "medication": {
      "medicationName": "Warfarin",
      "activeIngredient": null,
      "dosage": "5mg",
      "frequency": "Once daily",
      "route": null,
      "startDate": null,
      "endDate": null,
      "batchNumber": "BATCH-20251125-089",
      "indication": "Atrial Fibrillation"
    },
    "concomitantMedications": [],
    "reporterInformation": {
      "reporterName": "sarah@hospital.com",
      "reporterRole": "Cardiologist",
      "reporterContact": "dr.sarah@hospital.com"
    },
    "narrativeSummary": "67-year-old male on Warfarin...",
    "assessments": {
      "causality": "Probable",
      "relatedness": "Very High (Over-anticoagulation with Warfarin)",
      "preventability": "Preventable (with closer INR monitoring)"
    },
    "followUpActions": [
      {
        "actionType": "INR Monitoring",
        "actionDescription": null,
        "dueDate": null,
        "assignedTo": null,
        "status": "Pending"
      },
      {
        "actionType": "Drug Interaction Review",
        "actionDescription": null,
        "dueDate": null,
        "assignedTo": null,
        "status": "Pending"
      }
    ],
    "attachments": [],
    "metadata": {
      "createdBy": "Document Processor",
      "createdAt": "2025-12-11T09:12:02.6816567Z",
      "lastModifiedBy": null,
      "lastModifiedAt": null,
      "version": 1
    }
  }
]
```

### JSON Property Mapping

```
C# Property Name  →  JSON Property Name
─────────────────────────────────────────
CaseId           →  caseId
CaseStatus       →  caseStatus
DateOfIntake     →  dateOfIntake
SourceDocument   →  sourceDocument
PatientInformation → patientInformation
AdverseEvent     →  adverseEvent
Medication       →  medication
... etc
```

---

## Example Scenarios

### Scenario 1: Processing Text Email Report

**Input File:** `adverse_event_email.eml`

**Processing Steps:**

```
1. Load Email
   └─ MimeMessage.Load("adverse_event_email.eml")
   └─ Subject: "Adverse Event Report - Patient Follow-up"
   └─ From: Dr. Sarah Mitchell <dr.sarah@hospital.com>

2. Extract Content
   └─ Combine subject + body + sender into text

3. Parse with Regex
   └─ Find: "Patient ID: PAT-2025-005" → PatientId = "PAT-2025-005"
   └─ Find: "Age: 67" → Age = 67
   └─ Find: "Gender: Male" → Gender = "Male"
   └─ Find: "Weight: 82.5 kg" → Weight = 82.5
   └─ Find: "Medication Name: Warfarin" → MedicationName = "Warfarin"
   └─ Find: "Dosage: 5mg" → Dosage = "5mg"
   └─ Find: "Event Name: Severe Bleeding Episode" → EventName = "Severe Bleeding Episode"
   └─ Find: "Severity: Severe" → Severity = SeverityLevel.Severe
   └─ Find: "Causality: Probable" → Causality = CausalityAssessment.Probable

4. Create Case Object
   ├─ CaseId = "9228d079-..." (GUID)
   ├─ CaseStatus = New
   ├─ DateOfIntake = 2025-12-11T09:12:02Z
   ├─ SourceDocument.SourceType = "Email"
   ├─ PatientInformation populated
   ├─ Medication populated
   ├─ AdverseEvent populated
   ├─ ReporterInformation populated (from email headers)
   └─ Assessments populated

5. Validate
   ├─ AdverseEvent != null ✓
   ├─ AdverseEvent.EventName != empty ✓
   ├─ Medication != null ✓
   ├─ Medication.Name != empty ✓
   ├─ Medication.Dosage != empty ✓
   └─ PatientInformation != null ✓
   └─ Result: VALID

6. Create & Save
   ├─ Add to repository
   ├─ Set Metadata (CreatedBy = "Document Processor", Version = 1)
   └─ Return Case Object

7. Serialize to JSON
   └─ Add to output array

Output: Case successfully created and added to JSON
```

### Scenario 2: Processing Text File with Missing Medication Name

**Input File:** `case_notification.txt`

**Initial State (Before Fix):**

```
Processing: case_notification.txt...
  ├─ Extract patient info ✓ (PAT-2025-002, age 38)
  ├─ Extract medication ✗ (No "Medication Name:" field)
  ├─ Extract adverse event ✓ (Severe Allergic Reaction)
  └─ Create case object
  
Validation Check:
  ├─ AdverseEvent != null ✓
  ├─ AdverseEvent.EventName != empty ✓
  ├─ Medication != null ✓
  ├─ Medication.Name != empty ✗ ERROR
  └─ Result: INVALID

Error Message:
  ✗ Error processing case_notification.txt: Medication name is required

Action: Skip file, continue to next file
```

**After Fix (Adding "Medication Name" to file):**

```
Processing: case_notification.txt...
  ├─ Extract all fields ✓
  └─ Create case object

Validation Check:
  ├─ All required fields present ✓
  └─ Result: VALID

Output: Case successfully created
```

### Scenario 3: Batch Processing Multiple Files

**Input Folder:** `c:\sample_documents\` containing 4 files

```
Processing Sequence:
├─ File 1: adverse_event_email.eml
│   ├─ Process with EmailProcessor ✓
│   ├─ Extract & validate ✓
│   ├─ Create case (CASE-001)
│   └─ Display: "✓ Case created: CASE-001"
│
├─ File 2: adverse_event_report.txt
│   ├─ Process with LiteratureProcessor ✓
│   ├─ Extract & validate ✓
│   ├─ Create case (CASE-002)
│   └─ Display: "✓ Case created: CASE-002"
│
├─ File 3: case_notification.txt
│   ├─ Process with LiteratureProcessor ✓
│   ├─ Extract & validate ✓
│   ├─ Create case (CASE-003)
│   └─ Display: "✓ Case created: CASE-003"
│
└─ File 4: clinical_report.pdf
    ├─ Process with PdfProcessor ⚠️
    ├─ Extract fields (partially)
    ├─ Validation fails (missing fields)
    └─ Display: "✗ Error: Adverse event name is required..."

Final Summary:
Successfully processed 3/4 files

Consolidate Results:
  └─ [CASE-001, CASE-002, CASE-003]

Serialize & Save:
  └─ cases_20251211_144232.json
  └─ Display: "✓ Results saved to: c:\output\cases_20251211_144232.json"
```

---

## Technical Implementation Details

### Class Relationships

```
┌──────────────────────┐
│ PharmacovigilanceCase│  Main case domain model
└──────┬───────────────┘
       │ contains
       ├─ SourceDocument
       ├─ PatientInformation
       ├─ AdverseEvent
       ├─ Medication[]
       ├─ ReporterInformation
       ├─ CaseAssessments
       ├─ FollowUpAction[]
       ├─ Attachment[]
       └─ CaseMetadata

┌──────────────────────┐
│  IDocumentProcessor  │  Interface for all processors
└──────┬───────────────┘
       │ implemented by
       ├─ EmailProcessor (for .eml, .msg)
       ├─ PdfProcessor (for .pdf)
       └─ LiteratureProcessor (for .txt, generic)

┌──────────────────────┐
│  CaseIntakeService   │  Business logic service
└──────┬───────────────┘
       │ uses
       ├─ ICaseRepository (for persistence)
       └─ Validation rules

┌──────────────────────┐
│  MockCaseRepository  │  In-memory storage implementation
└──────────────────────┘
       └─ Dictionary<string, PharmacovigilanceCase>
```

### Data Type Conversions

```
Regex Match String → Target Type
─────────────────────────────────

"67" → int via int.TryParse("67", out int age)
"82.5" → double via double.TryParse("82.5", out double weight)
"Severe" → SeverityLevel.Severe via Enum.TryParse<SeverityLevel>("Severe", true, out var severity)
"Probable" → CausalityAssessment.Probable via Enum.TryParse<CausalityAssessment>("Probable", true, out var causality)
"2025-12-05" → DateTime (manual parsing if needed)
"10mg" → Kept as string (Dosage)
```

### Asynchronous Patterns

```csharp
// All document processing is async
public override async Task<PharmacovigilanceCase> ProcessDocumentAsync(
    string documentPath, 
    string documentType)
{
    // Document loading can be intensive for large files
    ValidateInput(documentPath, documentType);
    
    // Perform processing (sync operations wrapped in Task)
    var caseData = new PharmacovigilanceCase { ... };
    
    // Return Task.FromResult for immediate completion
    return await Task.FromResult(caseData);
}

// Service method is async for future database operations
public async Task<PharmacovigilanceCase> CreateCaseAsync(
    PharmacovigilanceCase caseData, 
    string createdBy)
{
    // Validation (sync)
    if (!ValidateCase(caseData))
        throw new ValidationException(...);
    
    // Future: await _dbContext.SaveChangesAsync();
    await _repository.SaveAsync(caseData);
    
    return caseData;
}
```

### Error Recovery

```csharp
// Graceful degradation strategy
foreach (var file in files)
{
    try
    {
        var caseData = await ProcessFileAsync(file, ...);
        
        if (caseData != null)
        {
            var savedCase = await caseService.CreateCaseAsync(caseData, "Document Processor");
            processedCases.Add(savedCase);
            // ✓ Success - continue
        }
        else
        {
            // File type unsupported - skip and continue
        }
    }
    catch (Exception ex)
    {
        // Log error and continue with next file
        Console.WriteLine($"✗ Error processing {file}: {ex.Message}");
        continue;  // Don't break entire batch
    }
}

// Report final statistics
Console.WriteLine($"Successfully processed {processedCount}/{files.Length} files");
```

---

## Performance Considerations

### Time Complexity

| Operation | Complexity | Notes |
|-----------|-----------|-------|
| File I/O | O(n) | n = file size |
| Regex matching | O(n*m) | n = text length, m = pattern count |
| Case object creation | O(1) | Constant time |
| Validation | O(1) | Fixed field checks |
| JSON serialization | O(n) | n = number of cases |
| **Total per file** | **O(n*m)** | Dominated by regex matching |

### Memory Usage

```
Per Case Object:
├─ CaseId (36 chars) = ~36 bytes
├─ Strings (avg 500 bytes each) × 10 = ~5 KB
├─ Collections (5 items × 1 KB each) = ~5 KB
├─ Objects (nested) = ~2 KB
└─ **Total per case: ~12-15 KB**

Batch Processing:
├─ 100 cases = ~1.2-1.5 MB
├─ 1000 cases = ~12-15 MB
└─ 10,000 cases = ~120-150 MB
```

### Optimization Opportunities

```
1. Parallel Processing
   └─ Use Parallel.ForEach for file processing
   └─ Process multiple files simultaneously

2. Caching
   └─ Cache compiled regex patterns
   └─ Precompile common patterns

3. Streaming
   └─ Process large files in chunks
   └─ Don't load entire file into memory

4. Database Batching
   └─ Batch save operations
   └─ Reduce database round-trips

5. Index Optimization
   └─ Index case fields for faster retrieval
   └─ Add database indexes on frequently searched fields
```

---

## Future Enhancements

### Short-term

1. **Better PDF Support**
   - Implement proper text extraction library
   - Add OCR for scanned documents

2. **Enhanced NLP**
   - Add entity recognition for medical terms
   - Machine learning-based field extraction

3. **Database Integration**
   - Replace in-memory repository
   - Add SQL/NoSQL persistence

### Medium-term

1. **REST API**
   - Build ASP.NET Core web service
   - Expose endpoints for case management

2. **User Interface**
   - Web dashboard for case review
   - Real-time processing status

3. **Notifications**
   - Email alerts for new cases
   - Webhook support for integrations

### Long-term

1. **Advanced Analytics**
   - Case trend analysis
   - Adverse event pattern detection
   - Risk prediction

2. **Integration Ecosystem**
   - Connect with EHR systems
   - FDA eCopy submission integration
   - Multi-language support

---

## Conclusion

The Pharmacovigilance Case Extraction and Creation system provides:

✅ **Multi-format document support** (Email, PDF, Text)
✅ **Intelligent data extraction** (Regex-based pattern matching)
✅ **Robust validation** (Required field checks)
✅ **Structured output** (JSON format)
✅ **Error resilience** (Graceful failure handling)
✅ **Extensible architecture** (Easy to add new processors)

This system successfully transforms unstructured medical documents into structured, validated case data ready for pharmacovigilance analysis and reporting.
