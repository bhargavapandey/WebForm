using System;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.IO;
using MimeKit;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;
using PharmacovigilanceIntakeService.Models;
using PharmacovigilanceIntakeService.Interfaces;

namespace PharmacovigilanceIntakeService.DocumentProcessing
{
    /// <summary>
    /// Base class for document processors
    /// </summary>
    public abstract class BaseDocumentProcessor : IDocumentProcessor
    {
        protected string[] SupportedTypes { get; set; }

        public virtual bool CanProcess(string documentType)
        {
            return Array.Exists(SupportedTypes, element => element.Equals(documentType, StringComparison.OrdinalIgnoreCase));
        }

        public abstract Task<PharmacovigilanceCase> ProcessDocumentAsync(string documentPath, string documentType);

        protected void ValidateInput(string documentPath, string documentType)
        {
            if (string.IsNullOrWhiteSpace(documentPath))
                throw new ArgumentException("Document path cannot be null or empty", nameof(documentPath));

            if (string.IsNullOrWhiteSpace(documentType))
                throw new ArgumentException("Document type cannot be null or empty", nameof(documentType));

            if (!CanProcess(documentType))
                throw new NotSupportedException($"Document type '{documentType}' is not supported by this processor");
        }
    }

    /// <summary>
    /// Email document processor
    /// </summary>
    public class EmailProcessor : BaseDocumentProcessor, IEmailProcessor
    {
        public EmailProcessor()
        {
            SupportedTypes = new[] { "Email", "EML", "MSG" };
        }

        public override async Task<PharmacovigilanceCase> ProcessDocumentAsync(string documentPath, string documentType)
        {
            ValidateInput(documentPath, documentType);

            try
            {
                var message = MimeMessage.Load(documentPath);
                
                // Extract text content from email
                string emailContent = ExtractEmailContent(message);
                
                // Parse the email content using literature processor logic
                var caseData = new PharmacovigilanceCase
                {
                    SourceDocument = new SourceDocument
                    {
                        SourceType = "Email",
                        SourceFileName = Path.GetFileName(documentPath),
                        ExtractionMethod = "NLP"
                    },
                    PatientInformation = ExtractPatientInfo(emailContent),
                    AdverseEvent = ExtractAdverseEvent(emailContent),
                    Medication = ExtractMedication(emailContent),
                    ReporterInformation = ExtractReporterInfo(message, emailContent),
                    NarrativeSummary = ExtractNarrativeSummary(emailContent),
                    Assessments = ExtractAssessments(emailContent),
                    FollowUpActions = ExtractFollowUpActions(emailContent)
                };

                return await Task.FromResult(caseData);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to process email file: {ex.Message}", ex);
            }
        }

        private string ExtractEmailContent(MimeMessage message)
        {
            var content = new System.Text.StringBuilder();

            // Add subject
            if (!string.IsNullOrEmpty(message.Subject))
                content.AppendLine($"Subject: {message.Subject}");

            // Add sender info
            if (message.From.Count > 0)
                content.AppendLine($"From: {message.From[0]}");

            // Add body
            if (message.TextBody != null)
                content.AppendLine(message.TextBody);
            else if (message.HtmlBody != null)
                content.AppendLine(StripHtml(message.HtmlBody));

            // Add attachment names
            foreach (var attachment in message.Attachments.OfType<MimePart>())
            {
                content.AppendLine($"Attachment: {attachment.FileName}");
            }

            return content.ToString();
        }

        private string StripHtml(string html)
        {
            return Regex.Replace(html, "<[^>]*>", " ");
        }

        private PatientInformation ExtractPatientInfo(string content)
        {
            var patientInfo = new PatientInformation();

            var patientIdMatch = Regex.Match(content, @"Patient ID:?\s*([A-Za-z0-9\-]+)", RegexOptions.IgnoreCase);
            if (patientIdMatch.Success)
                patientInfo.PatientId = patientIdMatch.Groups[1].Value;

            var ageMatch = Regex.Match(content, @"Age:?\s*(\d+)", RegexOptions.IgnoreCase);
            if (ageMatch.Success && int.TryParse(ageMatch.Groups[1].Value, out int age))
                patientInfo.Age = age;

            var genderMatch = Regex.Match(content, @"Gender:?\s*(Male|Female|Other)", RegexOptions.IgnoreCase);
            if (genderMatch.Success)
                patientInfo.Gender = genderMatch.Groups[1].Value;

            var weightMatch = Regex.Match(content, @"Weight:?\s*([\d.]+)\s*kg", RegexOptions.IgnoreCase);
            if (weightMatch.Success && double.TryParse(weightMatch.Groups[1].Value, out double weight))
                patientInfo.Weight = weight;

            return patientInfo;
        }

        private AdverseEvent ExtractAdverseEvent(string content)
        {
            var adverseEvent = new AdverseEvent();

            var eventNameMatch = Regex.Match(content, @"Event Name:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (eventNameMatch.Success)
                adverseEvent.EventName = eventNameMatch.Groups[1].Value.Trim();

            var severityMatch = Regex.Match(content, @"Severity:?\s*(Mild|Moderate|Severe|Life-threatening|Fatal)", RegexOptions.IgnoreCase);
            if (severityMatch.Success)
            {
                if (Enum.TryParse<SeverityLevel>(severityMatch.Groups[1].Value.Replace("-", ""), true, out var severity))
                    adverseEvent.Severity = severity;
            }

            var descMatch = Regex.Match(content, @"Description:?\s*([^\n]+(?:\n(?!.*:).*)*)", RegexOptions.IgnoreCase);
            if (descMatch.Success)
                adverseEvent.Description = descMatch.Groups[1].Value.Trim();

            adverseEvent.Seriousness = content.Contains("Serious", StringComparison.OrdinalIgnoreCase) ? "Serious" : "Non-serious";

            return adverseEvent;
        }

        private Medication ExtractMedication(string content)
        {
            var medication = new Medication();

            var medNameMatch = Regex.Match(content, @"Medication Name:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (medNameMatch.Success)
                medication.MedicationName = medNameMatch.Groups[1].Value.Trim();

            var dosageMatch = Regex.Match(content, @"Dosage:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (dosageMatch.Success)
                medication.Dosage = dosageMatch.Groups[1].Value.Trim();

            var frequencyMatch = Regex.Match(content, @"Frequency:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (frequencyMatch.Success)
                medication.Frequency = frequencyMatch.Groups[1].Value.Trim();

            var batchMatch = Regex.Match(content, @"Batch Number:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (batchMatch.Success)
                medication.BatchNumber = batchMatch.Groups[1].Value.Trim();

            var indicationMatch = Regex.Match(content, @"Indication:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (indicationMatch.Success)
                medication.Indication = indicationMatch.Groups[1].Value.Trim();

            return medication;
        }

        private ReporterInformation ExtractReporterInfo(MimeMessage message, string content)
        {
            var reporter = new ReporterInformation();

            // Try to get from email sender first
            if (message.From.Count > 0)
            {
                var sender = message.From[0] as MailboxAddress;
                if (sender != null)
                {
                    reporter.ReporterName = sender.Name ?? sender.Address;
                    reporter.ReporterContact = sender.Address;
                }
            }

            // Override with content if found
            var nameMatch = Regex.Match(content, @"Reporter:?\s*([^\n]+)|(?:Doctor|Dr\.|Physician):?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (nameMatch.Success)
                reporter.ReporterName = (nameMatch.Groups[1].Success ? nameMatch.Groups[1].Value : nameMatch.Groups[2].Value).Trim();

            var roleMatch = Regex.Match(content, @"Reporter Role:?\s*([^\n]+)|Role:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (roleMatch.Success)
                reporter.ReporterRole = (roleMatch.Groups[1].Success ? roleMatch.Groups[1].Value : roleMatch.Groups[2].Value).Trim();

            var contactMatch = Regex.Match(content, @"(?:Reporter Contact|Contact|Email):?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (contactMatch.Success)
                reporter.ReporterContact = contactMatch.Groups[1].Value.Trim();

            return reporter;
        }

        private string ExtractNarrativeSummary(string content)
        {
            var narrativeMatch = Regex.Match(content, @"NARRATIVE SUMMARY\s*-*\s*([^\n]+(?:\n(?!.*:).*)*)", RegexOptions.IgnoreCase);
            if (narrativeMatch.Success)
                return narrativeMatch.Groups[1].Value.Trim();

            var lines = content.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            var narrative = string.Join(" ", lines.Where(l => !l.Contains(":") && l.Length > 20).Take(3));
            return string.IsNullOrWhiteSpace(narrative) ? content.Substring(0, Math.Min(500, content.Length)) : narrative;
        }

        private CaseAssessments ExtractAssessments(string content)
        {
            var assessments = new CaseAssessments();

            var causalityMatch = Regex.Match(content, @"Causality:?\s*(Certain|Probable|Possible|Unlikely|Unrelated|Unknown)", RegexOptions.IgnoreCase);
            if (causalityMatch.Success)
            {
                if (Enum.TryParse<CausalityAssessment>(causalityMatch.Groups[1].Value, true, out var causality))
                    assessments.Causality = causality;
            }

            var relatednessMatch = Regex.Match(content, @"Relatedness:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (relatednessMatch.Success)
                assessments.Relatedness = relatednessMatch.Groups[1].Value.Trim();

            var preventabilityMatch = Regex.Match(content, @"Preventability:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (preventabilityMatch.Success)
                assessments.Preventability = preventabilityMatch.Groups[1].Value.Trim();

            return assessments;
        }

        private List<FollowUpAction> ExtractFollowUpActions(string content)
        {
            var followUpActions = new List<FollowUpAction>();
            var actionMatches = Regex.Matches(content, @"(\d+)\.\s*(?:Action Type|Type):?\s*([^\n]+)", RegexOptions.IgnoreCase);
            
            foreach (Match match in actionMatches)
            {
                var action = new FollowUpAction
                {
                    ActionType = match.Groups[2].Value.Trim(),
                    Status = "Pending"
                };
                followUpActions.Add(action);
            }

            return followUpActions;
        }
    }

    /// <summary>
    /// PDF document processor
    /// </summary>
    public class PdfProcessor : BaseDocumentProcessor, IPdfProcessor
    {
        public PdfProcessor()
        {
            SupportedTypes = new[] { "PDF", "pdf" };
        }

        public override async Task<PharmacovigilanceCase> ProcessDocumentAsync(string documentPath, string documentType)
        {
            ValidateInput(documentPath, documentType);

            try
            {
                // Extract text from PDF using PdfSharp
                string pdfContent = ExtractTextFromPdf(documentPath);

                // Parse the PDF content using literature processor logic
                var caseData = new PharmacovigilanceCase
                {
                    SourceDocument = new SourceDocument
                    {
                        SourceType = "PDF",
                        SourceFileName = Path.GetFileName(documentPath),
                        ExtractionMethod = "Text Extraction"
                    },
                    PatientInformation = ExtractPatientInfo(pdfContent),
                    AdverseEvent = ExtractAdverseEvent(pdfContent),
                    Medication = ExtractMedication(pdfContent),
                    ReporterInformation = ExtractReporterInfo(pdfContent),
                    NarrativeSummary = ExtractNarrativeSummary(pdfContent),
                    Assessments = ExtractAssessments(pdfContent),
                    FollowUpActions = ExtractFollowUpActions(pdfContent)
                };

                return await Task.FromResult(caseData);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"Failed to process PDF file: {ex.Message}", ex);
            }
        }

        private string ExtractTextFromPdf(string pdfPath)
        {
            var content = new System.Text.StringBuilder();

            try
            {
                using (PdfDocument document = PdfReader.Open(pdfPath, PdfDocumentOpenMode.Import))
                {
                    for (int pageIndex = 0; pageIndex < document.PageCount; pageIndex++)
                    {
                        PdfPage page = document.Pages[pageIndex];
                        
                        // Extract text from page (basic approach)
                        // Note: This is a simplified extraction. For better results, 
                        // consider using specialized PDF text extraction libraries
                        content.AppendLine($"--- Page {pageIndex + 1} ---");
                        
                        // Attempt to extract content stream
                        var contents = page.Contents;
                        if (contents != null)
                        {
                            // This is a simplified approach; full text extraction from PDFs is complex
                            content.AppendLine("[PDF content extraction - requires advanced PDF parsing]");
                        }
                    }
                }
            }
            catch
            {
                // If standard extraction fails, return minimal content
                content.AppendLine("[Unable to extract text from PDF. Ensure PDF contains searchable text.]");
            }

            return content.ToString();
        }

        private PatientInformation ExtractPatientInfo(string content)
        {
            var patientInfo = new PatientInformation();

            var patientIdMatch = Regex.Match(content, @"Patient ID:?\s*([A-Za-z0-9\-]+)", RegexOptions.IgnoreCase);
            if (patientIdMatch.Success)
                patientInfo.PatientId = patientIdMatch.Groups[1].Value;

            var ageMatch = Regex.Match(content, @"Age:?\s*(\d+)", RegexOptions.IgnoreCase);
            if (ageMatch.Success && int.TryParse(ageMatch.Groups[1].Value, out int age))
                patientInfo.Age = age;

            var genderMatch = Regex.Match(content, @"Gender:?\s*(Male|Female|Other)", RegexOptions.IgnoreCase);
            if (genderMatch.Success)
                patientInfo.Gender = genderMatch.Groups[1].Value;

            var weightMatch = Regex.Match(content, @"Weight:?\s*([\d.]+)\s*kg", RegexOptions.IgnoreCase);
            if (weightMatch.Success && double.TryParse(weightMatch.Groups[1].Value, out double weight))
                patientInfo.Weight = weight;

            return patientInfo;
        }

        private AdverseEvent ExtractAdverseEvent(string content)
        {
            var adverseEvent = new AdverseEvent();

            var eventNameMatch = Regex.Match(content, @"Event Name:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (eventNameMatch.Success)
                adverseEvent.EventName = eventNameMatch.Groups[1].Value.Trim();

            var severityMatch = Regex.Match(content, @"Severity:?\s*(Mild|Moderate|Severe|Life-threatening|Fatal)", RegexOptions.IgnoreCase);
            if (severityMatch.Success)
            {
                if (Enum.TryParse<SeverityLevel>(severityMatch.Groups[1].Value.Replace("-", ""), true, out var severity))
                    adverseEvent.Severity = severity;
            }

            var descMatch = Regex.Match(content, @"Description:?\s*([^\n]+(?:\n(?!.*:).*)*)", RegexOptions.IgnoreCase);
            if (descMatch.Success)
                adverseEvent.Description = descMatch.Groups[1].Value.Trim();

            adverseEvent.Seriousness = content.Contains("Serious", StringComparison.OrdinalIgnoreCase) ? "Serious" : "Non-serious";

            return adverseEvent;
        }

        private Medication ExtractMedication(string content)
        {
            var medication = new Medication();

            var medNameMatch = Regex.Match(content, @"Medication Name:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (medNameMatch.Success)
                medication.MedicationName = medNameMatch.Groups[1].Value.Trim();

            var dosageMatch = Regex.Match(content, @"Dosage:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (dosageMatch.Success)
                medication.Dosage = dosageMatch.Groups[1].Value.Trim();

            var frequencyMatch = Regex.Match(content, @"Frequency:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (frequencyMatch.Success)
                medication.Frequency = frequencyMatch.Groups[1].Value.Trim();

            var batchMatch = Regex.Match(content, @"Batch Number:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (batchMatch.Success)
                medication.BatchNumber = batchMatch.Groups[1].Value.Trim();

            var indicationMatch = Regex.Match(content, @"Indication:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (indicationMatch.Success)
                medication.Indication = indicationMatch.Groups[1].Value.Trim();

            return medication;
        }

        private ReporterInformation ExtractReporterInfo(string content)
        {
            var reporter = new ReporterInformation();

            var nameMatch = Regex.Match(content, @"Reporter:?\s*([^\n]+)|(?:Doctor|Dr\.|Physician):?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (nameMatch.Success)
                reporter.ReporterName = (nameMatch.Groups[1].Success ? nameMatch.Groups[1].Value : nameMatch.Groups[2].Value).Trim();

            var roleMatch = Regex.Match(content, @"Reporter Role:?\s*([^\n]+)|Role:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (roleMatch.Success)
                reporter.ReporterRole = (roleMatch.Groups[1].Success ? roleMatch.Groups[1].Value : roleMatch.Groups[2].Value).Trim();

            var contactMatch = Regex.Match(content, @"(?:Reporter Contact|Contact|Email):?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (contactMatch.Success)
                reporter.ReporterContact = contactMatch.Groups[1].Value.Trim();

            return reporter;
        }

        private string ExtractNarrativeSummary(string content)
        {
            var narrativeMatch = Regex.Match(content, @"NARRATIVE SUMMARY\s*-*\s*([^\n]+(?:\n(?!.*:).*)*)", RegexOptions.IgnoreCase);
            if (narrativeMatch.Success)
                return narrativeMatch.Groups[1].Value.Trim();

            var lines = content.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
            var narrative = string.Join(" ", lines.Where(l => !l.Contains(":") && l.Length > 20).Take(3));
            return string.IsNullOrWhiteSpace(narrative) ? content.Substring(0, Math.Min(500, content.Length)) : narrative;
        }

        private CaseAssessments ExtractAssessments(string content)
        {
            var assessments = new CaseAssessments();

            var causalityMatch = Regex.Match(content, @"Causality:?\s*(Certain|Probable|Possible|Unlikely|Unrelated|Unknown)", RegexOptions.IgnoreCase);
            if (causalityMatch.Success)
            {
                if (Enum.TryParse<CausalityAssessment>(causalityMatch.Groups[1].Value, true, out var causality))
                    assessments.Causality = causality;
            }

            var relatednessMatch = Regex.Match(content, @"Relatedness:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (relatednessMatch.Success)
                assessments.Relatedness = relatednessMatch.Groups[1].Value.Trim();

            var preventabilityMatch = Regex.Match(content, @"Preventability:?\s*([^\n]+)", RegexOptions.IgnoreCase);
            if (preventabilityMatch.Success)
                assessments.Preventability = preventabilityMatch.Groups[1].Value.Trim();

            return assessments;
        }

        private List<FollowUpAction> ExtractFollowUpActions(string content)
        {
            var followUpActions = new List<FollowUpAction>();
            var actionMatches = Regex.Matches(content, @"(\d+)\.\s*(?:Action Type|Type):?\s*([^\n]+)", RegexOptions.IgnoreCase);
            
            foreach (Match match in actionMatches)
            {
                var action = new FollowUpAction
                {
                    ActionType = match.Groups[2].Value.Trim(),
                    Status = "Pending"
                };
                followUpActions.Add(action);
            }

            return followUpActions;
        }
    }

    /// <summary>
    /// Literature/Text document processor
    /// </summary>
    public class LiteratureProcessor : BaseDocumentProcessor, ILiteratureProcessor
    {
        public LiteratureProcessor()
        {
            SupportedTypes = new[] { "Literature", "Text", "TXT" };
        }

        public override async Task<PharmacovigilanceCase> ProcessDocumentAsync(string documentPath, string documentType)
        {
            ValidateInput(documentPath, documentType);

            // Read the text file
            string content = System.IO.File.ReadAllText(documentPath);

            var caseData = new PharmacovigilanceCase
            {
                SourceDocument = new SourceDocument
                {
                    SourceType = "Literature",
                    SourceFileName = System.IO.Path.GetFileName(documentPath),
                    ExtractionMethod = "NLP"
                },
                PatientInformation = ExtractPatientInfo(content),
                AdverseEvent = ExtractAdverseEvent(content),
                Medication = ExtractMedication(content),
                ReporterInformation = ExtractReporterInfo(content),
                NarrativeSummary = ExtractNarrativeSummary(content),
                Assessments = ExtractAssessments(content),
                FollowUpActions = ExtractFollowUpActions(content)
            };

            return await Task.FromResult(caseData);
        }

        private PatientInformation ExtractPatientInfo(string content)
        {
            var patientInfo = new PatientInformation();

            var patientIdMatch = System.Text.RegularExpressions.Regex.Match(content, @"Patient ID:?\s*([A-Za-z0-9\-]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (patientIdMatch.Success)
                patientInfo.PatientId = patientIdMatch.Groups[1].Value;

            var ageMatch = System.Text.RegularExpressions.Regex.Match(content, @"Age:?\s*(\d+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (ageMatch.Success && int.TryParse(ageMatch.Groups[1].Value, out int age))
                patientInfo.Age = age;

            var genderMatch = System.Text.RegularExpressions.Regex.Match(content, @"Gender:?\s*(Male|Female|Other)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (genderMatch.Success)
                patientInfo.Gender = genderMatch.Groups[1].Value;

            var weightMatch = System.Text.RegularExpressions.Regex.Match(content, @"Weight:?\s*([\d.]+)\s*kg", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (weightMatch.Success && double.TryParse(weightMatch.Groups[1].Value, out double weight))
                patientInfo.Weight = weight;

            return patientInfo;
        }

        private AdverseEvent ExtractAdverseEvent(string content)
        {
            var adverseEvent = new AdverseEvent();

            var eventNameMatch = System.Text.RegularExpressions.Regex.Match(content, @"Event Name:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (eventNameMatch.Success)
                adverseEvent.EventName = eventNameMatch.Groups[1].Value.Trim();

            var severityMatch = System.Text.RegularExpressions.Regex.Match(content, @"Severity:?\s*(Mild|Moderate|Severe|Life-threatening|Fatal)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (severityMatch.Success)
            {
                if (Enum.TryParse<SeverityLevel>(severityMatch.Groups[1].Value.Replace("-", ""), true, out var severity))
                    adverseEvent.Severity = severity;
            }

            var descMatch = System.Text.RegularExpressions.Regex.Match(content, @"Description:?\s*([^\n]+(?:\n(?!.*:).*)*)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (descMatch.Success)
                adverseEvent.Description = descMatch.Groups[1].Value.Trim();

            adverseEvent.Seriousness = content.Contains("Serious", System.StringComparison.OrdinalIgnoreCase) ? "Serious" : "Non-serious";

            return adverseEvent;
        }

        private Medication ExtractMedication(string content)
        {
            var medication = new Medication();

            var medNameMatch = System.Text.RegularExpressions.Regex.Match(content, @"Medication Name:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (medNameMatch.Success)
                medication.MedicationName = medNameMatch.Groups[1].Value.Trim();

            var dosageMatch = System.Text.RegularExpressions.Regex.Match(content, @"Dosage:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (dosageMatch.Success)
                medication.Dosage = dosageMatch.Groups[1].Value.Trim();

            var frequencyMatch = System.Text.RegularExpressions.Regex.Match(content, @"Frequency:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (frequencyMatch.Success)
                medication.Frequency = frequencyMatch.Groups[1].Value.Trim();

            var batchMatch = System.Text.RegularExpressions.Regex.Match(content, @"Batch Number:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (batchMatch.Success)
                medication.BatchNumber = batchMatch.Groups[1].Value.Trim();

            var indicationMatch = System.Text.RegularExpressions.Regex.Match(content, @"Indication:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (indicationMatch.Success)
                medication.Indication = indicationMatch.Groups[1].Value.Trim();

            return medication;
        }

        private ReporterInformation ExtractReporterInfo(string content)
        {
            var reporter = new ReporterInformation();

            var nameMatch = System.Text.RegularExpressions.Regex.Match(content, @"Reporter:?\s*([^\n]+)|(?:Doctor|Dr\.|Physician):?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (nameMatch.Success)
                reporter.ReporterName = (nameMatch.Groups[1].Success ? nameMatch.Groups[1].Value : nameMatch.Groups[2].Value).Trim();

            var roleMatch = System.Text.RegularExpressions.Regex.Match(content, @"Reporter Role:?\s*([^\n]+)|Role:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (roleMatch.Success)
                reporter.ReporterRole = (roleMatch.Groups[1].Success ? roleMatch.Groups[1].Value : roleMatch.Groups[2].Value).Trim();

            var contactMatch = System.Text.RegularExpressions.Regex.Match(content, @"(?:Reporter Contact|Contact|Email):?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (contactMatch.Success)
                reporter.ReporterContact = contactMatch.Groups[1].Value.Trim();

            return reporter;
        }

        private string ExtractNarrativeSummary(string content)
        {
            var narrativeMatch = System.Text.RegularExpressions.Regex.Match(content, @"NARRATIVE SUMMARY\s*-*\s*([^\n]+(?:\n(?!.*:).*)*)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (narrativeMatch.Success)
                return narrativeMatch.Groups[1].Value.Trim();

            // If no specific narrative section, return first substantial paragraph
            var lines = content.Split(new[] { '\n' }, System.StringSplitOptions.RemoveEmptyEntries);
            var narrative = string.Join(" ", lines.Where(l => !l.Contains(":") && l.Length > 20).Take(3));
            return string.IsNullOrWhiteSpace(narrative) ? content.Substring(0, Math.Min(500, content.Length)) : narrative;
        }

        private CaseAssessments ExtractAssessments(string content)
        {
            var assessments = new CaseAssessments();

            var causalityMatch = System.Text.RegularExpressions.Regex.Match(content, @"Causality:?\s*(Certain|Probable|Possible|Unlikely|Unrelated|Unknown)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (causalityMatch.Success)
            {
                if (Enum.TryParse<CausalityAssessment>(causalityMatch.Groups[1].Value, true, out var causality))
                    assessments.Causality = causality;
            }

            var relatednessMatch = System.Text.RegularExpressions.Regex.Match(content, @"Relatedness:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (relatednessMatch.Success)
                assessments.Relatedness = relatednessMatch.Groups[1].Value.Trim();

            var preventabilityMatch = System.Text.RegularExpressions.Regex.Match(content, @"Preventability:?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            if (preventabilityMatch.Success)
                assessments.Preventability = preventabilityMatch.Groups[1].Value.Trim();

            return assessments;
        }

        private List<FollowUpAction> ExtractFollowUpActions(string content)
        {
            var followUpActions = new List<FollowUpAction>();

            // Look for numbered follow-up actions
            var actionMatches = System.Text.RegularExpressions.Regex.Matches(content, @"(\d+)\.\s*(?:Action Type|Type):?\s*([^\n]+)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            
            foreach (System.Text.RegularExpressions.Match match in actionMatches)
            {
                var action = new FollowUpAction
                {
                    ActionType = match.Groups[2].Value.Trim(),
                    Status = "Pending"
                };
                followUpActions.Add(action);
            }

            return followUpActions;
        }
    }
}
