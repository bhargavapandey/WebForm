# Pharmacovigilance Case Intake Service

A comprehensive C# service for reading from unstructured data sources (emails, PDFs, literature) and creating structured case intakes for Pharmacovigilance systems.

## Features

- **Multi-Source Document Processing**: Handle emails, PDFs, and literature documents
- **Structured Case Models**: Comprehensive JSON schema and C# models for Pharmacovigilance cases
- **NLP Extraction**: Extract medical entities and information from unstructured text
- **Case Management**: Create, update, and manage Pharmacovigilance cases
- **Data Validation**: Built-in validation for case data integrity
- **Extensible Architecture**: Interface-based design for easy integration of new processors

## Project Structure

```
PharmacovigilanceIntakeService/
├── Models/                          # Core data models
│   ├── CaseModels.cs               # C# models for cases
│   └── CaseSchema.json             # JSON schema definition
├── Interfaces/                      # Service interfaces
│   └── ProcessingInterfaces.cs      # Document processing & case interfaces
├── Services/                        # Service implementations
├── DocumentProcessing/              # Document processors
│   ├── EmailProcessor.cs
│   ├── PdfProcessor.cs
│   └── LiteratureProcessor.cs
└── PharmacovigilanceIntakeService.csproj
```

## Getting Started

### Prerequisites

- .NET 8.0 SDK or higher
- Visual Studio 2022 or Visual Studio Code with C# extension

### Installation

1. Clone or open the project in VS Code
2. Restore dependencies:
   ```bash
   dotnet restore
   ```
3. Build the project:
   ```bash
   dotnet build
   ```

## Core Models

### PharmacovigilanceCase
Main case model containing:
- Patient information
- Adverse event details
- Medication information
- Reporter details
- Case assessments
- Follow-up actions
- Supporting attachments

### Supporting Models
- `AdverseEvent`: Adverse event with severity and outcome
- `Medication`: Medication details with dosage and route
- `PatientInformation`: Patient demographics and history
- `CaseAssessments`: Causality and preventability assessments
- `SourceDocument`: Source document metadata

## Interfaces

### IDocumentProcessor
Base interface for all document processors

### Document-Specific Processors
- `IEmailProcessor`: Process email documents
- `IPdfProcessor`: Process PDF documents
- `ILiteratureProcessor`: Process literature/text documents

### ICaseIntakeService
Manages case creation, update, and validation

### INlpExtractor
Extracts medical entities using NLP

### ICaseRepository
Persistence layer for case storage

## Next Steps

1. Implement document processors in `DocumentProcessing/`
2. Implement NLP extraction services
3. Implement case repository for persistence
4. Add API endpoints for case intake
5. Create unit tests

## Technologies Used

- **.NET 8.0**: Latest .NET framework
- **System.Text.Json**: JSON serialization/deserialization
- **iTextSharp**: PDF processing
- **MimeKit/MailKit**: Email processing
- **ML.NET**: Machine learning and NLP capabilities
- **Microsoft.Extensions**: DI, Configuration, Logging

## Contributing

Please follow C# coding standards and ensure all new features have corresponding unit tests.

## License

[Add your license information]
