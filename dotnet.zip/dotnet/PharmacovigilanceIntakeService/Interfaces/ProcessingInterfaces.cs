using System.Threading.Tasks;
using PharmacovigilanceIntakeService.Models;

namespace PharmacovigilanceIntakeService.Interfaces
{
    /// <summary>
    /// Interface for extracting data from unstructured documents
    /// </summary>
    public interface IDocumentProcessor
    {
        /// <summary>
        /// Process a document and extract case information
        /// </summary>
        /// <param name="documentPath">Path to the document</param>
        /// <param name="documentType">Type of document (Email, PDF, Literature)</param>
        /// <returns>Extracted case data</returns>
        Task<PharmacovigilanceCase> ProcessDocumentAsync(string documentPath, string documentType);

        /// <summary>
        /// Check if the processor can handle the given document type
        /// </summary>
        bool CanProcess(string documentType);
    }

    /// <summary>
    /// Interface for processing email documents
    /// </summary>
    public interface IEmailProcessor : IDocumentProcessor
    {
    }

    /// <summary>
    /// Interface for processing PDF documents
    /// </summary>
    public interface IPdfProcessor : IDocumentProcessor
    {
    }

    /// <summary>
    /// Interface for processing literature/text documents
    /// </summary>
    public interface ILiteratureProcessor : IDocumentProcessor
    {
    }

    /// <summary>
    /// Interface for the case intake service
    /// </summary>
    public interface ICaseIntakeService
    {
        /// <summary>
        /// Create a new case from extracted document data
        /// </summary>
        Task<PharmacovigilanceCase> CreateCaseAsync(PharmacovigilanceCase caseData, string createdBy);

        /// <summary>
        /// Update an existing case
        /// </summary>
        Task<PharmacovigilanceCase> UpdateCaseAsync(PharmacovigilanceCase caseData, string modifiedBy);

        /// <summary>
        /// Get a case by ID
        /// </summary>
        Task<PharmacovigilanceCase> GetCaseAsync(string caseId);

        /// <summary>
        /// Validate case data
        /// </summary>
        /// <returns>True if valid, false otherwise</returns>
        bool ValidateCase(PharmacovigilanceCase caseData);

        /// <summary>
        /// Get validation errors for a case
        /// </summary>
        string[] GetValidationErrors(PharmacovigilanceCase caseData);
    }

    /// <summary>
    /// Interface for NLP-based data extraction
    /// </summary>
    public interface INlpExtractor
    {
        /// <summary>
        /// Extract medical entities from text
        /// </summary>
        Task<AdverseEvent> ExtractAdverseEventAsync(string text);

        /// <summary>
        /// Extract medication information from text
        /// </summary>
        Task<Medication> ExtractMedicationAsync(string text);

        /// <summary>
        /// Extract patient information from text
        /// </summary>
        Task<PatientInformation> ExtractPatientInformationAsync(string text);

        /// <summary>
        /// Extract narrative summary from unstructured text
        /// </summary>
        Task<string> ExtractNarrativeSummaryAsync(string text);
    }

    /// <summary>
    /// Interface for case repository/persistence
    /// </summary>
    public interface ICaseRepository
    {
        /// <summary>
        /// Save a case
        /// </summary>
        Task SaveAsync(PharmacovigilanceCase caseData);

        /// <summary>
        /// Get a case by ID
        /// </summary>
        Task<PharmacovigilanceCase> GetByIdAsync(string caseId);

        /// <summary>
        /// Update a case
        /// </summary>
        Task UpdateAsync(PharmacovigilanceCase caseData);

        /// <summary>
        /// Delete a case
        /// </summary>
        Task DeleteAsync(string caseId);
    }
}
