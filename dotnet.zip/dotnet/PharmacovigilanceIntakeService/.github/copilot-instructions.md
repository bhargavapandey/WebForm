# GitHub Copilot Instructions

This project is a C# .NET service for Pharmacovigilance case intake from unstructured data sources.

## Project Overview
- **Language**: C# (.NET 8.0)
- **Purpose**: Process emails, PDFs, and literature documents to create structured case intakes
- **Architecture**: Service-oriented with interface-based design

## Key Areas

### Models (Models/)
- `CaseModels.cs`: Complete C# models mirroring the JSON schema
- `CaseSchema.json`: JSON schema for case intake structure

### Interfaces (Interfaces/)
- Document processors for different source types
- Case management services
- NLP extraction interfaces
- Repository pattern for data persistence

### Implementation Areas
- DocumentProcessing/: Processor implementations
- Services/: Core business logic
- Repository implementations for persistence

## Code Standards
- Use nullable reference types (#nullable enable)
- Follow async/await patterns
- Use interface-based design
- Add XML documentation comments
- Implement dependency injection

## Next Development Tasks
1. Create email processor using MimeKit/MailKit
2. Create PDF processor using iTextSharp
3. Create NLP extractor using ML.NET
4. Implement case repository
5. Create case intake service
