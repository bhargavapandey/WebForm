using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PharmacovigilanceIntakeService.Models
{
    /// <summary>
    /// Enum for case status values
    /// </summary>
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum CaseStatus
    {
        New,
        UnderReview,
        Approved,
        Rejected,
        Closed
    }

    /// <summary>
    /// Enum for adverse event severity levels
    /// </summary>
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum SeverityLevel
    {
        Mild,
        Moderate,
        Severe,
        LifeThreatening,
        Fatal
    }

    /// <summary>
    /// Enum for adverse event outcome
    /// </summary>
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EventOutcome
    {
        Recovered,
        Recovering,
        NotRecovered,
        Fatal,
        Unknown
    }

    /// <summary>
    /// Enum for causality assessment
    /// </summary>
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum CausalityAssessment
    {
        Certain,
        Probable,
        Possible,
        Unlikely,
        Unrelated,
        Unknown
    }

    /// <summary>
    /// Main Pharmacovigilance Case model
    /// </summary>
    public class PharmacovigilanceCase
    {
        [JsonPropertyName("caseId")]
        public string CaseId { get; set; }

        [JsonPropertyName("caseStatus")]
        public CaseStatus CaseStatus { get; set; }

        [JsonPropertyName("dateOfIntake")]
        public DateTime DateOfIntake { get; set; }

        [JsonPropertyName("sourceDocument")]
        public SourceDocument SourceDocument { get; set; }

        [JsonPropertyName("patientInformation")]
        public PatientInformation PatientInformation { get; set; }

        [JsonPropertyName("adverseEvent")]
        public AdverseEvent AdverseEvent { get; set; }

        [JsonPropertyName("medication")]
        public Medication Medication { get; set; }

        [JsonPropertyName("concomitantMedications")]
        public List<Medication> ConcomitantMedications { get; set; }

        [JsonPropertyName("reporterInformation")]
        public ReporterInformation ReporterInformation { get; set; }

        [JsonPropertyName("narrativeSummary")]
        public string NarrativeSummary { get; set; }

        [JsonPropertyName("assessments")]
        public CaseAssessments Assessments { get; set; }

        [JsonPropertyName("followUpActions")]
        public List<FollowUpAction> FollowUpActions { get; set; }

        [JsonPropertyName("attachments")]
        public List<Attachment> Attachments { get; set; }

        [JsonPropertyName("metadata")]
        public CaseMetadata Metadata { get; set; }

        public PharmacovigilanceCase()
        {
            CaseId = Guid.NewGuid().ToString();
            DateOfIntake = DateTime.UtcNow;
            CaseStatus = CaseStatus.New;
            ConcomitantMedications = new List<Medication>();
            FollowUpActions = new List<FollowUpAction>();
            Attachments = new List<Attachment>();
        }
    }

    /// <summary>
    /// Source document information
    /// </summary>
    public class SourceDocument
    {
        [JsonPropertyName("sourceType")]
        public string SourceType { get; set; }

        [JsonPropertyName("sourceFileName")]
        public string SourceFileName { get; set; }

        [JsonPropertyName("extractionMethod")]
        public string ExtractionMethod { get; set; }
    }

    /// <summary>
    /// Patient information
    /// </summary>
    public class PatientInformation
    {
        [JsonPropertyName("patientId")]
        public string PatientId { get; set; }

        [JsonPropertyName("age")]
        public int? Age { get; set; }

        [JsonPropertyName("gender")]
        public string Gender { get; set; }

        [JsonPropertyName("weight")]
        public double? Weight { get; set; }

        [JsonPropertyName("medicalHistory")]
        public List<string> MedicalHistory { get; set; }

        public PatientInformation()
        {
            MedicalHistory = new List<string>();
        }
    }

    /// <summary>
    /// Adverse event details
    /// </summary>
    public class AdverseEvent
    {
        [JsonPropertyName("eventName")]
        public string EventName { get; set; }

        [JsonPropertyName("eventDate")]
        public DateTime? EventDate { get; set; }

        [JsonPropertyName("severity")]
        public SeverityLevel Severity { get; set; }

        [JsonPropertyName("seriousness")]
        public string Seriousness { get; set; }

        [JsonPropertyName("outcome")]
        public EventOutcome? Outcome { get; set; }

        [JsonPropertyName("description")]
        public string Description { get; set; }
    }

    /// <summary>
    /// Medication details
    /// </summary>
    public class Medication
    {
        [JsonPropertyName("medicationName")]
        public string MedicationName { get; set; }

        [JsonPropertyName("activeIngredient")]
        public string ActiveIngredient { get; set; }

        [JsonPropertyName("dosage")]
        public string Dosage { get; set; }

        [JsonPropertyName("frequency")]
        public string Frequency { get; set; }

        [JsonPropertyName("route")]
        public string Route { get; set; }

        [JsonPropertyName("startDate")]
        public DateTime? StartDate { get; set; }

        [JsonPropertyName("endDate")]
        public DateTime? EndDate { get; set; }

        [JsonPropertyName("batchNumber")]
        public string BatchNumber { get; set; }

        [JsonPropertyName("indication")]
        public string Indication { get; set; }
    }

    /// <summary>
    /// Reporter information
    /// </summary>
    public class ReporterInformation
    {
        [JsonPropertyName("reporterName")]
        public string ReporterName { get; set; }

        [JsonPropertyName("reporterRole")]
        public string ReporterRole { get; set; }

        [JsonPropertyName("reporterContact")]
        public string ReporterContact { get; set; }
    }

    /// <summary>
    /// Case assessments
    /// </summary>
    public class CaseAssessments
    {
        [JsonPropertyName("causality")]
        public CausalityAssessment? Causality { get; set; }

        [JsonPropertyName("relatedness")]
        public string Relatedness { get; set; }

        [JsonPropertyName("preventability")]
        public string Preventability { get; set; }
    }

    /// <summary>
    /// Follow-up action item
    /// </summary>
    public class FollowUpAction
    {
        [JsonPropertyName("actionType")]
        public string ActionType { get; set; }

        [JsonPropertyName("actionDescription")]
        public string ActionDescription { get; set; }

        [JsonPropertyName("dueDate")]
        public DateTime? DueDate { get; set; }

        [JsonPropertyName("assignedTo")]
        public string AssignedTo { get; set; }

        [JsonPropertyName("status")]
        public string Status { get; set; }
    }

    /// <summary>
    /// Attachment information
    /// </summary>
    public class Attachment
    {
        [JsonPropertyName("fileName")]
        public string FileName { get; set; }

        [JsonPropertyName("fileType")]
        public string FileType { get; set; }

        [JsonPropertyName("fileUrl")]
        public string FileUrl { get; set; }
    }

    /// <summary>
    /// Case metadata
    /// </summary>
    public class CaseMetadata
    {
        [JsonPropertyName("createdBy")]
        public string CreatedBy { get; set; }

        [JsonPropertyName("createdAt")]
        public DateTime CreatedAt { get; set; }

        [JsonPropertyName("lastModifiedBy")]
        public string LastModifiedBy { get; set; }

        [JsonPropertyName("lastModifiedAt")]
        public DateTime? LastModifiedAt { get; set; }

        [JsonPropertyName("version")]
        public int Version { get; set; }

        public CaseMetadata()
        {
            CreatedAt = DateTime.UtcNow;
            Version = 1;
        }
    }
}
