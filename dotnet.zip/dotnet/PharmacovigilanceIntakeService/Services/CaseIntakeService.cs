using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using PharmacovigilanceIntakeService.Models;
using PharmacovigilanceIntakeService.Interfaces;

namespace PharmacovigilanceIntakeService.Services
{
    /// <summary>
    /// Service for case intake management
    /// </summary>
    public class CaseIntakeService : ICaseIntakeService
    {
        private readonly ICaseRepository _repository;

        public CaseIntakeService(ICaseRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        public async Task<PharmacovigilanceCase> CreateCaseAsync(PharmacovigilanceCase caseData, string createdBy)
        {
            if (caseData == null)
                throw new ArgumentNullException(nameof(caseData));

            if (string.IsNullOrWhiteSpace(createdBy))
                throw new ArgumentException("Created by user name cannot be null or empty", nameof(createdBy));

            if (!ValidateCase(caseData))
            {
                var errors = GetValidationErrors(caseData);
                throw new ValidationException($"Case validation failed: {string.Join(", ", errors)}");
            }

            caseData.Metadata = new CaseMetadata
            {
                CreatedBy = createdBy,
                CreatedAt = DateTime.UtcNow,
                Version = 1
            };

            caseData.CaseId = Guid.NewGuid().ToString();
            caseData.DateOfIntake = DateTime.UtcNow;

            await _repository.SaveAsync(caseData);

            return caseData;
        }

        public async Task<PharmacovigilanceCase> UpdateCaseAsync(PharmacovigilanceCase caseData, string modifiedBy)
        {
            if (caseData == null)
                throw new ArgumentNullException(nameof(caseData));

            if (string.IsNullOrWhiteSpace(caseData.CaseId))
                throw new ArgumentException("Case ID cannot be null or empty", nameof(caseData));

            if (string.IsNullOrWhiteSpace(modifiedBy))
                throw new ArgumentException("Modified by user name cannot be null or empty", nameof(modifiedBy));

            if (!ValidateCase(caseData))
            {
                var errors = GetValidationErrors(caseData);
                throw new ValidationException($"Case validation failed: {string.Join(", ", errors)}");
            }

            if (caseData.Metadata == null)
                caseData.Metadata = new CaseMetadata();

            caseData.Metadata.LastModifiedBy = modifiedBy;
            caseData.Metadata.LastModifiedAt = DateTime.UtcNow;
            caseData.Metadata.Version++;

            await _repository.UpdateAsync(caseData);

            return caseData;
        }

        public async Task<PharmacovigilanceCase> GetCaseAsync(string caseId)
        {
            if (string.IsNullOrWhiteSpace(caseId))
                throw new ArgumentException("Case ID cannot be null or empty", nameof(caseId));

            return await _repository.GetByIdAsync(caseId);
        }

        public bool ValidateCase(PharmacovigilanceCase caseData)
        {
            return GetValidationErrors(caseData).Length == 0;
        }

        public string[] GetValidationErrors(PharmacovigilanceCase caseData)
        {
            var errors = new List<string>();

            if (caseData == null)
                return new[] { "Case data is null" };

            // Validate required fields
            if (caseData.AdverseEvent == null)
                errors.Add("Adverse event is required");
            else
            {
                if (string.IsNullOrWhiteSpace(caseData.AdverseEvent.EventName))
                    errors.Add("Adverse event name is required");
            }

            if (caseData.Medication == null)
                errors.Add("Medication is required");
            else
            {
                if (string.IsNullOrWhiteSpace(caseData.Medication.MedicationName))
                    errors.Add("Medication name is required");
                if (string.IsNullOrWhiteSpace(caseData.Medication.Dosage))
                    errors.Add("Medication dosage is required");
            }

            if (caseData.PatientInformation == null)
                errors.Add("Patient information is required");

            // Validate case status
            if (!Enum.IsDefined(typeof(CaseStatus), caseData.CaseStatus))
                errors.Add("Invalid case status");

            return errors.ToArray();
        }
    }
}
