using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.Json.Serialization;
using PharmacovigilanceIntakeService.Models;
using PharmacovigilanceIntakeService.Services;
using PharmacovigilanceIntakeService.DocumentProcessing;
using PharmacovigilanceIntakeService.Interfaces;

namespace PharmacovigilanceIntakeService
{
    /// <summary>
    /// In-memory mock repository for testing
    /// </summary>
    public class MockCaseRepository : ICaseRepository
    {
        private readonly Dictionary<string, PharmacovigilanceCase> _cases = new();

        public Task SaveAsync(PharmacovigilanceCase caseData)
        {
            if (caseData == null)
                throw new ArgumentNullException(nameof(caseData));

            _cases[caseData.CaseId] = caseData;
            return Task.CompletedTask;
        }

        public Task<PharmacovigilanceCase> GetByIdAsync(string caseId)
        {
            if (string.IsNullOrWhiteSpace(caseId))
                throw new ArgumentException("Case ID cannot be null", nameof(caseId));

            if (_cases.TryGetValue(caseId, out var caseData))
                return Task.FromResult(caseData);

            return Task.FromResult<PharmacovigilanceCase>(null!);
        }

        public Task UpdateAsync(PharmacovigilanceCase caseData)
        {
            if (caseData == null)
                throw new ArgumentNullException(nameof(caseData));

            if (!_cases.ContainsKey(caseData.CaseId))
                throw new KeyNotFoundException($"Case {caseData.CaseId} not found");

            _cases[caseData.CaseId] = caseData;
            return Task.CompletedTask;
        }

        public Task DeleteAsync(string caseId)
        {
            if (string.IsNullOrWhiteSpace(caseId))
                throw new ArgumentException("Case ID cannot be null", nameof(caseId));

            _cases.Remove(caseId);
            return Task.CompletedTask;
        }

        public int GetCaseCount() => _cases.Count;

        public IEnumerable<PharmacovigilanceCase> GetAllCases() => _cases.Values;
    }

    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("\n╔════════════════════════════════════════════════════════════════╗");
            Console.WriteLine("║   Pharmacovigilance Case Intake Service - Document Processor    ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");

            try
            {
                if (args.Length == 0)
                {
                    ShowUsage();
                    return;
                }

                string path = args[0];
                string outputFolder = args.Length > 1 ? args[1] : "./output";

                // Ensure output directory exists
                if (!Directory.Exists(outputFolder))
                {
                    Directory.CreateDirectory(outputFolder);
                }

                // Initialize services
                var repository = new MockCaseRepository();
                var caseService = new CaseIntakeService(repository);
                var emailProcessor = new EmailProcessor();
                var pdfProcessor = new PdfProcessor();
                var literatureProcessor = new LiteratureProcessor();

                List<PharmacovigilanceCase> processedCases = new();

                // Process single file
                if (File.Exists(path))
                {
                    Console.WriteLine($"📄 Processing file: {Path.GetFileName(path)}");
                    Console.WriteLine("─────────────────────────────────────────────\n");
                    
                    var caseData = await ProcessFileAsync(path, emailProcessor, pdfProcessor, literatureProcessor);
                    if (caseData != null)
                    {
                        var savedCase = await caseService.CreateCaseAsync(caseData, "Document Processor");
                        processedCases.Add(savedCase);
                        DisplayCaseDetails(savedCase);
                    }
                }
                // Process folder
                else if (Directory.Exists(path))
                {
                    var files = Directory.GetFiles(path, "*.*", SearchOption.AllDirectories);
                    Console.WriteLine($"📁 Processing folder: {path}");
                    Console.WriteLine($"Found {files.Length} file(s)\n");

                    if (files.Length == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("⚠️  No files found in the folder.");
                        Console.ResetColor();
                        return;
                    }

                    int processedCount = 0;
                    foreach (var file in files)
                    {
                        try
                        {
                            Console.WriteLine($"Processing: {Path.GetFileName(file)}...");
                            var caseData = await ProcessFileAsync(file, emailProcessor, pdfProcessor, literatureProcessor);
                            
                            if (caseData != null)
                            {
                                var savedCase = await caseService.CreateCaseAsync(caseData, "Document Processor");
                                processedCases.Add(savedCase);
                                Console.WriteLine($"  ✓ Case created: {savedCase.CaseId}\n");
                                processedCount++;
                            }
                            else
                            {
                                Console.WriteLine($"  ✗ Unsupported file type or failed to process\n");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine($"  ✗ Error processing {Path.GetFileName(file)}: {ex.Message}\n");
                            Console.ResetColor();
                        }
                    }

                    Console.WriteLine($"Successfully processed {processedCount}/{files.Length} files\n");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"❌ Error: Path not found: {path}");
                    Console.ResetColor();
                    ShowUsage();
                    return;
                }

                // Save results to JSON
                if (processedCases.Count > 0)
                {
                    Console.WriteLine("💾 Saving results...");
                    Console.WriteLine("─────────────────────────────────────────────\n");
                    
                    string jsonOutputPath = Path.Combine(outputFolder, $"cases_{DateTime.Now:yyyyMMdd_HHmmss}.json");
                    SaveCasesToJson(processedCases, jsonOutputPath);
                    
                    Console.WriteLine($"✓ Results saved to: {jsonOutputPath}\n");
                }

                Console.WriteLine("╔════════════════════════════════════════════════════════════════╗");
                Console.WriteLine($"║  ✓ Processing Complete - {processedCases.Count} case(s) created  │");
                Console.WriteLine("╚════════════════════════════════════════════════════════════════╝\n");
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\n❌ Error: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                Console.ResetColor();
            }
        }

        static async Task<PharmacovigilanceCase?> ProcessFileAsync(
            string filePath,
            EmailProcessor emailProcessor,
            PdfProcessor pdfProcessor,
            LiteratureProcessor literatureProcessor)
        {
            if (!File.Exists(filePath))
                return null;

            string extension = Path.GetExtension(filePath).ToLower();

            try
            {
                switch (extension)
                {
                    case ".eml":
                    case ".msg":
                        return await emailProcessor.ProcessDocumentAsync(filePath, "Email");

                    case ".pdf":
                        return await pdfProcessor.ProcessDocumentAsync(filePath, "PDF");

                    case ".txt":
                    case ".text":
                        return await literatureProcessor.ProcessDocumentAsync(filePath, "Literature");

                    default:
                        // Try to read as text
                        if (IsTextFile(filePath))
                        {
                            return await literatureProcessor.ProcessDocumentAsync(filePath, "Literature");
                        }
                        return null;
                }
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"⚠️  Warning: Could not process {Path.GetFileName(filePath)}: {ex.Message}");
                Console.ResetColor();
                return null;
            }
        }

        static bool IsTextFile(string filePath)
        {
            try
            {
                using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                using (var reader = new StreamReader(fileStream))
                {
                    char[] buffer = new char[512];
                    int charsRead = reader.Read(buffer, 0, buffer.Length);
                    
                    for (int i = 0; i < charsRead; i++)
                    {
                        if (char.IsControl(buffer[i]) && !char.IsWhiteSpace(buffer[i]))
                            return false;
                    }
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        static void DisplayCaseDetails(PharmacovigilanceCase caseData)
        {
            Console.WriteLine($"Case ID: {caseData.CaseId}");
            Console.WriteLine($"Status: {caseData.CaseStatus}");
            Console.WriteLine($"Date: {caseData.DateOfIntake:g}");
            
            if (caseData.PatientInformation != null)
            {
                Console.WriteLine($"Patient: {caseData.PatientInformation.PatientId} (Age: {caseData.PatientInformation.Age})");
            }
            
            if (caseData.AdverseEvent != null)
            {
                Console.WriteLine($"Event: {caseData.AdverseEvent.EventName} ({caseData.AdverseEvent.Severity})");
            }
            
            if (caseData.Medication != null)
            {
                Console.WriteLine($"Medication: {caseData.Medication.MedicationName} - {caseData.Medication.Dosage}");
            }
            
            Console.WriteLine();
        }

        static void SaveCasesToJson(List<PharmacovigilanceCase> cases, string outputPath)
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true,
                DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase
            };

            string json = JsonSerializer.Serialize(cases, options);
            File.WriteAllText(outputPath, json);
        }

        static void ShowUsage()
        {
            Console.WriteLine("USAGE:");
            Console.WriteLine("─────────────────────────────────────────────\n");
            Console.WriteLine("Process a single file:");
            Console.WriteLine("  dotnet run <file_path> [output_folder]\n");
            Console.WriteLine("Process a folder:");
            Console.WriteLine("  dotnet run <folder_path> [output_folder]\n");
            Console.WriteLine("EXAMPLES:");
            Console.WriteLine("─────────────────────────────────────────────\n");
            Console.WriteLine("Single file:");
            Console.WriteLine("  dotnet run C:\\documents\\patient_report.eml\n");
            Console.WriteLine("Process folder with custom output:");
            Console.WriteLine("  dotnet run C:\\emails C:\\output\\cases\n");
            Console.WriteLine("Supported file types:");
            Console.WriteLine("  • Email: .eml, .msg");
            Console.WriteLine("  • PDF: .pdf");
            Console.WriteLine("  • Text: .txt, .text, or any text-based file\n");
        }
    }
}
